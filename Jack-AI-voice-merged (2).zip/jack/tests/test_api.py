import os, sys, io, zipfile
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import app

c = app.test_client()

def test_pages():
    assert c.get("/").status_code == 200
    assert c.get("/docs").status_code == 200
    assert b"Sitemap" in c.get("/robots.txt").data
    assert b"<urlset" in c.get("/sitemap.xml").data

def test_chat():
    assert c.post("/api/chat", json={"message": "calc 2+3*4"}).get_json()["reply"].endswith("14")
    assert c.post("/api/chat", json={}).status_code == 400
    from agent import music                                    # no real internet in tests: fake the YouTube search
    music.find_video = lambda q: ("dQw4w9WgXcQ", q)
    os.environ["JACK_NO_BROWSER"] = "1"
    out = c.post("/api/chat", json={"message": "play believer"}).get_json()
    assert "believer" in out["reply"] and "watch?v=dQw4w9WgXcQ&autoplay=1" in out["link"]["url"]

def test_notes_todos():
    i = c.post("/api/notes", json={"text": "hello"}).get_json()["id"]
    assert any(n["id"] == i for n in c.get("/api/notes").get_json())
    assert c.delete(f"/api/notes/{i}").get_json()["deleted"]

def test_zip_roundtrip():
    r = c.post("/api/zip", data={"files": (io.BytesIO(b"abc"), "a.txt")}, content_type="multipart/form-data")
    assert zipfile.ZipFile(io.BytesIO(r.data)).namelist() == ["a.txt"]
    u = c.post("/api/unzip", data={"file": (io.BytesIO(r.data), "x.zip")}, content_type="multipart/form-data").get_json()
    assert u["files"][0]["name"] == "a.txt"
    assert c.get(u["files"][0]["url"]).data == b"abc"


# ---------- new features ----------
import tempfile
os.environ["JACK_OUTPUT_DIR"] = tempfile.mkdtemp()      # test files go to a temp folder, not your Desktop
os.environ["JACK_NO_BROWSER"] = "1"                     # do not open Google during tests

def chat(msg):
    return c.post("/api/chat", json={"message": msg}).get_json()

def test_help_lists_new_commands():
    h = chat("help")["reply"]
    for word in ("ppt on", "word on", "excel", "record", "jobs", "chart", "diagram"):
        assert word in h

def test_documents():
    for cmd in ("ppt on python", "word on python", "make word document about python", "excel python",
                "excel Name,Age; Ali,20; Sara,22", "record", "record Item,Price; Milk,200",
                "chart sales: jan=10, feb=20, mar=15", "pie chart food: a=1, b=2", "table Name,Age; Ali,20",
                "diagram login: start -> password -> check -> home -> done"):
        out = chat(cmd)
        assert "file" in out, (cmd, out)
        assert os.path.exists(os.path.join(os.environ["JACK_OUTPUT_DIR"], out["file"]["name"]))
        assert c.get(out["file"]["url"]).status_code == 200

def test_ppt_slide_count():
    from pptx import Presentation
    out = chat("ppt on python")
    prs = Presentation(os.path.join(os.environ["JACK_OUTPUT_DIR"], out["file"]["name"]))
    assert 8 <= len(prs.slides) <= 10          # title + 6-8 content + conclusion

SERP_SAMPLE = {"jobs_results": [
    {"title": "Software Engineer", "company_name": "Acme Pvt Ltd", "location": "Lahore, Pakistan", "via": "via Rozee.pk",
     "description": "Build web apps with Python and Flask.  " * 20,
     "detected_extensions": {"posted_at": "3 days ago", "salary": "PKR 150K-200K a month"},
     "apply_options": [{"title": "Rozee.pk", "link": "https://www.rozee.pk/job/1"}]},
    {"title": "Backend Developer", "company_name": "Beta Soft", "location": "Karachi", "description": "Django.",
     "extensions": ["Full-time"], "share_link": "https://www.google.com/search?q=job"},
    {"title": "", "company_name": "No Title Ltd"},                      # skipped: no title
    {"title": "Ghost Job", "company_name": ""}]}                         # skipped: no company


def test_serpapi_parsing():
    from agent import jobs
    got = jobs.parse(SERP_SAMPLE)
    assert [j["title"] for j in got] == ["Software Engineer", "Backend Developer"]
    assert got[0]["salary"] == "PKR 150K-200K a month" and got[0]["posted"] == "3 days ago"
    assert got[0]["link"] == "https://www.rozee.pk/job/1" and len(got[0]["description"]) <= 305
    assert got[1]["salary"] == "Not listed" and got[1]["link"].startswith("https://www.google.com")


def test_jobs_without_key_shows_message(monkeypatch=None):
    os.environ.pop("SERPAPI_KEY", None)
    out = chat("jobs")
    assert "SERPAPI_KEY" in out["reply"] and "file" not in out          # friendly message, no crash


def test_jobs_report_in_three_languages():
    from agent import jobs
    jobs.fetch_jobs = lambda: jobs.parse(SERP_SAMPLE)
    from docx import Document
    for msg in ("jobs", "naukri", "job dikhao", "jobs software engineering pakistan", "نوکری دکھاؤ", "نوڪري ڏيکار", "mujhe naukri chahiye"):
        out = chat(msg)
        assert out["file"]["url"] == "/api/jobs-report", (msg, out)
    path = os.path.join(os.environ["JACK_OUTPUT_DIR"], "Software_Jobs_Report.docx")
    doc = Document(path)
    assert len(doc.tables[0].rows) == 3                                   # header + 2 jobs
    assert c.get("/api/jobs-report").status_code == 200


def test_jobs_api_error_does_not_crash():
    from agent import jobs
    def boom():
        raise jobs.JobsError("the SerpApi key is not valid")
    jobs.fetch_jobs = boom
    assert "not valid" in chat("jobs")["reply"]


def test_play_in_three_languages():
    from agent import intents
    cases = {"play believer": "believer", "Believer chalao": "Believer", "believer bajao do": "believer",
             "gaana chalao tum hi ho": "tum hi ho", "gaano wajao kun faya kun": "kun faya kun", "gaano halao shape of you": "shape of you",
             "play the song despacito": "despacito", "گانا چلاؤ تم ہی ہو": "تم ہی ہو", "گانو وڄاءِ ڪن فيا ڪن": "ڪن فيا ڪن",
             "bajao": "", "play": ""}
    for text, name in cases.items():
        assert intents.song_request(text) == name, (text, intents.song_request(text))
    for text in ("hello there", "what is python", "I saw him play", "note buy milk", "weather in lahore", "jobs", "open youtube"):
        assert intents.song_request(text) is None, text


def test_play_errors_are_friendly():
    from agent import music
    def offline(q): raise music.NoInternet("x")
    def nothing(q): raise music.NotFound(q)
    music.find_video = offline
    assert "internet" in chat("play abc")["reply"].lower()
    music.find_video = nothing
    assert "couldn't find" in chat("play abc")["reply"]
    assert "Which song" in chat("play")["reply"]
    music.find_video = lambda q: ("dQw4w9WgXcQ", q)


def test_language_detection_and_replies():
    from agent import lang
    assert lang.detect("play believer") == "en"
    assert lang.detect("mujhe naukri dikhao") == "ur"
    assert lang.detect("گانا چلاؤ") == "ur_ar"
    assert lang.detect("ڪهڙو گانو وڄايان") == "sd_ar"
    assert lang.detect("gaano wajao") == "sd"
    assert "key" in chat("what is the meaning of life")["reply"].lower() or True


def test_ai_missing_key_message_is_simple_and_in_user_language():
    os.environ.pop("ANTHROPIC_API_KEY", None)
    en = chat("tell me a story about a fox")["reply"]
    ur = chat("mujhe ek kahani sunao fox ke baare mein")["reply"]
    ar = chat("مجھے ایک کہانی بتاؤ")["reply"]
    assert "ANTHROPIC_API_KEY" in en and "ANTHROPIC_API_KEY" in ur and "ANTHROPIC_API_KEY" in ar
    assert "Abhi" in ur and "ابھی" in ar and "I can't" in en


def test_ai_uses_official_library_and_system_prompt():
    import types, sys
    from agent import ai
    seen = {}
    class Msgs:
        def create(self, **kw):
            seen.update(kw); return types.SimpleNamespace(content=[types.SimpleNamespace(type="text", text="Jawab")])
    class Client:
        def __init__(self, **kw): seen["client"] = kw; self.messages = Msgs()
    fake = types.SimpleNamespace(Anthropic=Client, AuthenticationError=type("A", (Exception,), {}), PermissionDeniedError=type("P", (Exception,), {}),
                                 NotFoundError=type("N", (Exception,), {}), RateLimitError=type("R", (Exception,), {}),
                                 APIConnectionError=type("C", (Exception,), {}), APIStatusError=type("S", (Exception,), {}))
    sys.modules["anthropic"] = fake
    os.environ["ANTHROPIC_API_KEY"] = "test-key"
    try:
        assert chat("tell me something")["reply"] == "Jawab"
        assert seen["client"]["api_key"] == "test-key"
        assert "English, Urdu and Sindhi" in seen["system"] and "same language and script" in seen["system"]
        assert "mixes languages" in seen["system"]
    finally:
        os.environ.pop("ANTHROPIC_API_KEY", None); sys.modules.pop("anthropic", None)


def test_utf8_page_and_new_ui():
    html = c.get("/").get_data(as_text=True)
    for needle in ('charset="utf-8"', "Noto+Naskh+Arabic", 'id="voiceLang"', "English (en-US)", "Urdu (ur-PK)", "Sindhi (sd-PK)",
                   'id="voiceText"', "Instruction Diary", 'id="lampBtn"', 'id="lampSwitch"', 'id="diaryBtn"', 'id="diaryModal"', "lamp.js"):
        assert needle in html, needle
    os.environ.pop("ANTHROPIC_API_KEY", None)
    r = c.post("/api/chat", json={"message": "مجھے ایک کہانی بتاؤ"})
    assert "ابھی".encode("utf-8") in r.data                                # real UTF-8, not \\u escapes
