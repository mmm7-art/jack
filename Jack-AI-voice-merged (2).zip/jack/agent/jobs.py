"""Job search with the SerpApi Google Jobs API  ->  Word report on the Desktop.

The old DuckDuckGo / Bing page scraping (which returned quizzes, YouTube pages and quote sites) was removed.
The key is read from the environment variable SERPAPI_KEY (put it in the .env file, never in the code).
"""
import datetime as dt
import os
import re

from . import documents, web

QUERY = "software engineer Pakistan"
LOCATION = "Pakistan"
REPORT_NAME = "Software_Jobs_Report.docx"


class JobsError(Exception):
    """Something went wrong with the job search. The text is shown to the user (simple language)."""


class NoKey(JobsError):
    """SERPAPI_KEY is not set."""


# ---------------------------------------------------------------- where the report is saved
def desktop_dir():
    """Desktop folder, found with os.path.expanduser('~/Desktop').
    (JACK_OUTPUT_DIR can override it - the tests use this so they do not write to your real Desktop.)"""
    if os.getenv("JACK_OUTPUT_DIR"):
        folder = os.getenv("JACK_OUTPUT_DIR")
    else:
        folder = os.path.expanduser("~/Desktop")
        if not os.path.isdir(folder):                           # some Windows PCs keep the Desktop inside OneDrive
            alt = os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop")
            folder = alt if os.path.isdir(alt) else folder
    os.makedirs(folder, exist_ok=True)
    return folder


def report_path():
    return os.path.join(desktop_dir(), REPORT_NAME)


# ---------------------------------------------------------------- SerpApi
def _clean(text):
    return re.sub(r"\s+", " ", text or "").strip()


def _short(text, n=300):
    text = _clean(text)
    return text if len(text) <= n else text[:n].rsplit(" ", 1)[0].rstrip(",;:.") + "..."


def _salary(job):
    """Salary exactly as Google Jobs gives it (no guessing with regular expressions)."""
    det = job.get("detected_extensions") or {}
    if det.get("salary"):
        return _clean(str(det["salary"]))
    for ext in job.get("extensions") or []:
        low = str(ext).lower()
        if any(w in low for w in ("a month", "an hour", "a year", "a week", "a day", "per month", "pkr", "rs.", "rs ")):
            return _clean(str(ext))
    return "Not listed"


def _posted(job):
    det = job.get("detected_extensions") or {}
    if det.get("posted_at"):
        return _clean(str(det["posted_at"]))
    for ext in job.get("extensions") or []:
        if re.search(r"\bago\b|today|yesterday", str(ext), re.I):
            return _clean(str(ext))
    return "Not listed"


def _apply_link(job):
    for opt in job.get("apply_options") or []:
        if opt.get("link"):
            return opt["link"]
    if job.get("share_link"):
        return job["share_link"]
    for rel in job.get("related_links") or []:
        if rel.get("link"):
            return rel["link"]
    return ""


def parse(data):
    """SerpApi 'jobs_results' -> clean list. Results with no title or no company are skipped."""
    jobs = []
    for j in (data or {}).get("jobs_results") or []:
        title, company = _clean(j.get("title")), _clean(j.get("company_name"))
        if not title or not company:
            continue
        jobs.append({"title": title, "company": company,
                     "location": _clean(j.get("location")) or "Not listed",
                     "salary": _salary(j), "posted": _posted(j),
                     "description": _short(j.get("description")) or "Not listed",
                     "link": _apply_link(j)})
    return jobs


def _call_serpapi(key):
    params = {"engine": "google_jobs", "q": QUERY, "location": LOCATION, "hl": "en", "api_key": key}
    try:
        from serpapi import GoogleSearch                       # pip package: google-search-results
        return GoogleSearch(params).get_dict()
    except ImportError:                                        # package missing: plain web request instead
        from urllib.parse import urlencode
        return web.get_json("https://serpapi.com/search.json?" + urlencode(params), timeout=30)


def fetch_jobs():
    """Calls SerpApi and returns the clean job list. Raises NoKey / JobsError with a simple message."""
    key = (os.getenv("SERPAPI_KEY") or "").strip()
    if not key:
        raise NoKey("SERPAPI_KEY is missing")
    try:
        data = _call_serpapi(key)
    except Exception as e:
        msg = str(e).lower()
        if "401" in msg or "invalid api key" in msg:
            raise JobsError("the SerpApi key is not valid")
        if "429" in msg or "limit" in msg:
            raise JobsError("the SerpApi search limit is finished")
        raise JobsError("could not reach SerpApi (check your internet)")
    err = (data or {}).get("error")
    if err:
        if "hasn't returned any results" in err or "no results" in err.lower():
            return []                                          # not an error: Google just had no jobs
        if "invalid api key" in err.lower():
            raise JobsError("the SerpApi key is not valid")
        raise JobsError("SerpApi said: " + _short(err, 120))
    return parse(data)


# ---------------------------------------------------------------- the Word report
def make_report(jobs, path=None):
    from docx import Document
    from docx.shared import Pt
    doc = Document()
    doc.add_heading("Software Engineering Jobs in Pakistan", 0)
    doc.add_paragraph(f"Prepared by Jack on {dt.datetime.now():%d %B %Y, %I:%M %p}.  Jobs found: {len(jobs)}.  "
                      "Source: Google Jobs (via SerpApi). Always check the apply link before you apply.")
    doc.add_heading("Summary table", 1)
    t = doc.add_table(rows=1, cols=6)
    t.style = "Table Grid"
    for i, h in enumerate(["#", "Job title", "Company", "Location", "Salary", "Posted"]):
        t.rows[0].cells[i].text = h
        t.rows[0].cells[i].paragraphs[0].runs[0].bold = True
    for n, j in enumerate(jobs, 1):
        cells = t.add_row().cells
        for i, v in enumerate([n, j["title"], j["company"], j["location"], j["salary"], j["posted"]]):
            cells[i].text = str(v)
    for row in t.rows:
        for c in row.cells:
            for para in c.paragraphs:
                for r in para.runs:
                    r.font.size = Pt(9)
    doc.add_heading("Job details", 1)
    for n, j in enumerate(jobs, 1):
        doc.add_heading(f"{n}. {j['title']}", 2)
        for label, key in (("Company", "company"), ("Location", "location"), ("Salary", "salary"),
                           ("Posted", "posted"), ("Description", "description")):
            para = doc.add_paragraph(style="List Bullet")
            para.add_run(label + ": ").bold = True
            para.add_run(j[key])
        para = doc.add_paragraph(style="List Bullet")
        para.add_run("Apply link: ").bold = True
        if j["link"]:
            documents.add_link(para, j["link"], j["link"][:90])
        else:
            para.add_run("Not listed")
    path = path or report_path()
    doc.save(path)
    return path


def run():
    """Full job command. Returns (word_file_path, number_of_jobs). Raises NoKey / JobsError on problems."""
    jobs = fetch_jobs()
    if not jobs:
        return None, 0
    return make_report(jobs), len(jobs)
