"""Web helpers. Every request uses the certifi CA bundle (fixes SSL errors on Windows)."""
import json, os, ssl, urllib.request
import certifi

os.environ.setdefault("SSL_CERT_FILE", certifi.where())       # for any other library too
CTX = ssl.create_default_context(cafile=certifi.where())       # our own SSL context
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) JackAgent/2.0"}


def get_text(url, headers=None, data=None, timeout=8):
    """Download a URL and return the text."""
    req = urllib.request.Request(url, headers=headers or UA, data=data)
    with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
        return r.read().decode("utf-8", "ignore")


def get_json(url, headers=None, data=None, timeout=8):
    """Download a URL and return parsed JSON."""
    return json.loads(get_text(url, headers, data, timeout))
