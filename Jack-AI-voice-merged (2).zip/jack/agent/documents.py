"""Creates PowerPoint, Word, Excel, chart, table and diagram files.
Everything is saved in the 'Jack Output' folder on your Desktop."""
import os, re, json, datetime as dt
from pathlib import Path
from urllib.parse import quote
from . import store, web, ai

SKIP = {"references", "see also", "external links", "notes", "further reading", "bibliography",
        "citations", "sources", "footnotes", "gallery"}


# ---------------------------------------------------------------- folders and file names
def output_dir():
    """Desktop/Jack Output (works with the OneDrive Desktop on Windows too)."""
    if os.getenv("JACK_OUTPUT_DIR"):                       # optional override (used by tests)
        folder = Path(os.getenv("JACK_OUTPUT_DIR"))
    else:
        home = Path.home()
        options = [home / "OneDrive" / "Desktop", home / "Desktop"]
        if os.getenv("OneDrive"):
            options.insert(0, Path(os.getenv("OneDrive")) / "Desktop")
        desktop = next((p for p in options if p.exists()), home / "Desktop")
        folder = desktop / "Jack Output"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def new_path(prefix, topic, ext):
    """Example: Jack Output/PPT_Python_20250101_093000.pptx"""
    slug = re.sub(r"[^A-Za-z0-9]+", "_", topic).strip("_")[:40] or "file"
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    return output_dir() / f"{prefix}_{slug}_{stamp}.{ext}"


# ---------------------------------------------------------------- content (the text inside the files)
def _short(text, n=160):
    """Cut long sentences at a word boundary."""
    text = text.strip()
    if len(text) <= n:
        return text
    return text[:n].rsplit(" ", 1)[0].rstrip(",;:") + "..."


def _sentences(text):
    text = re.sub(r"\s+", " ", re.sub(r"\[\d+\]", "", text)).strip()
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(])", text)
    return [p.strip() for p in parts if len(p.strip()) > 25]


def _ai_outline(topic):
    """Best quality: ask Claude (only if ANTHROPIC_API_KEY is set)."""
    prompt = (f"Write presentation content about: {topic}\n"
              'Return ONLY JSON: {"title": str, "sections": [{"heading": str, "points": [4 short factual sentences]}], '
              '"conclusion": [3 short sentences]}. Use exactly 7 sections.')
    raw = ai.ask(prompt, system="You write accurate, clear study material. Output valid JSON only.",
                 max_tokens=2500, timeout=40)
    if not raw:
        return None
    data = json.loads(raw[raw.index("{"): raw.rindex("}") + 1])
    if not data.get("sections"):
        return None
    data["source"] = "Claude AI"
    return data


def _wiki_outline(topic):
    """Free option: real article text from Wikipedia, split into sections."""
    q = quote(topic)
    hits = web.get_json("https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=1&srsearch=" + q)
    hits = hits["query"]["search"]
    if not hits:
        return None
    title = hits[0]["title"]
    d = web.get_json("https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&redirects=1"
                     "&format=json&titles=" + quote(title))
    text = next(iter(d["query"]["pages"].values())).get("extract", "")
    parts = re.split(r"\n=+ *(.+?) *=+\n", "\n" + text)       # [intro, heading, body, heading, body...]
    intro = _sentences(parts[0])
    sections, pool = [], list(intro[4:])
    if intro:
        sections.append({"heading": "Overview", "points": intro[:4]})
    for i in range(1, len(parts) - 1, 2):
        pts = _sentences(parts[i + 1])
        if parts[i].lower() in SKIP or len(pts) < 2:
            continue
        sections.append({"heading": parts[i], "points": pts[:4]})
        pool += pts[4:]
    while len(sections) < 6 and len(pool) >= 3:                # not enough sections: use leftover sentences
        sections.append({"heading": f"More about {title}", "points": pool[:4]})
        pool = pool[4:]
    if len(sections) < 3:
        return None
    sections = sections[:8]
    names = ", ".join(s["heading"] for s in sections[1:4])
    return {"title": title, "sections": sections, "source": "Wikipedia",
            "conclusion": [_short(intro[0] if intro else title, 200), f"We covered: {names}.",
                           "Read more: en.wikipedia.org/wiki/" + title.replace(" ", "_")]}


def _template_outline(topic):
    """Offline fallback: a generic structure (no internet needed)."""
    t = topic.title()
    S = lambda h, *p: {"heading": h, "points": list(p)}
    return {"title": t, "source": "template", "sections": [
        S("Introduction", f"{t} is a subject that many people want to understand well.",
          "This presentation gives a clear overview in simple steps."),
        S("Background", f"Every field has a history, and {t} is no exception.",
          "Knowing where it started helps explain where it is going."),
        S("Key Concepts", f"The main ideas of {t} can be learned one at a time.",
          "Start with the basic terms, then move to examples."),
        S("How It Works", "Break the topic into small parts and study each part.",
          "Real examples make the ideas easier to remember."),
        S("Benefits", f"Learning {t} builds useful knowledge and skills.",
          "It can save time, improve decisions and open new opportunities."),
        S("Challenges", "Every topic has difficulties, such as cost, time or complexity.",
          "Planning ahead helps to avoid common mistakes."),
        S("Future Outlook", f"{t} will keep changing as technology and society change.",
          "Staying curious is the best way to keep up.")],
        "conclusion": [f"{t} is worth studying step by step.", "Practice and real examples build understanding.",
                       "Connect to the internet or add ANTHROPIC_API_KEY for richer content."]}


def get_outline(topic):
    """Try Claude AI, then Wikipedia, then the offline template."""
    for fn in (_ai_outline, _wiki_outline):
        try:
            result = fn(topic)
            if result:
                return result
        except Exception:
            pass
    return _template_outline(topic)


# ---------------------------------------------------------------- PowerPoint
def make_ppt(topic):
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE

    o = get_outline(topic)
    NAVY, ACCENT, TEXT, GREY = RGBColor(0x14, 0x1B, 0x3C), RGBColor(0x3B, 0x6F, 0xF5), RGBColor(0x22, 0x2B, 0x45), RGBColor(0x8A, 0x92, 0xAA)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)      # 16:9
    blank = prs.slide_layouts[6]

    def box(slide, x, y, w, h, color):
        s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
        s.fill.solid(); s.fill.fore_color.rgb = color; s.line.fill.background()

    def text(slide, x, y, w, h, lines, size, color, bold=False, gap=0):
        tf = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)).text_frame
        tf.word_wrap = True
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            r = p.add_run(); r.text = line
            r.font.size, r.font.bold, r.font.color.rgb, r.font.name = Pt(size), bold, color, "Calibri"
            p.space_after = Pt(gap)

    # 1) Title slide
    s = prs.slides.add_slide(blank)
    box(s, 0, 0, 13.333, 7.5, NAVY); box(s, 0.9, 3.0, 1.4, 0.08, ACCENT)
    text(s, 0.9, 1.3, 11.5, 1.7, [o["title"]], 44, RGBColor(255, 255, 255), True)
    text(s, 0.9, 3.3, 11, 1, ["Created by Jack, your personal AI agent", dt.datetime.now().strftime("%d %B %Y")], 18, RGBColor(0xB8, 0xC4, 0xF0), gap=4)

    # 2) Content slides + 3) Conclusion
    def content(title, bullets, n):
        s = prs.slides.add_slide(blank)
        box(s, 0, 0, 0.25, 7.5, ACCENT)
        text(s, 0.8, 0.5, 11.8, 1, [title], 32, NAVY, True)
        text(s, 0.8, 1.7, 11.6, 5, ["•  " + _short(b, 170) for b in bullets], 20, TEXT, gap=14)
        text(s, 12.2, 6.9, 0.8, 0.4, [str(n)], 12, GREY)

    for n, sec in enumerate(o["sections"][:8], start=2):
        content(sec["heading"], sec["points"], n)
    content("Conclusion", o["conclusion"], len(o["sections"][:8]) + 2)

    path = new_path("PPT", topic, "pptx")
    prs.save(path)
    return path, f"{len(prs.slides)} slides, content from {o['source']}"


# ---------------------------------------------------------------- Word
def add_link(paragraph, url, label):
    """Adds a clickable hyperlink to a Word paragraph."""
    from docx.oxml.shared import OxmlElement
    from docx.oxml.ns import qn
    r_id = paragraph.part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
    link = OxmlElement("w:hyperlink"); link.set(qn("r:id"), r_id)
    run, props = OxmlElement("w:r"), OxmlElement("w:rPr")
    for tag, val in (("w:color", "0563C1"), ("w:u", "single")):
        el = OxmlElement(tag); el.set(qn("w:val"), val); props.append(el)
    text = OxmlElement("w:t"); text.text = label
    run.append(props); run.append(text); link.append(run); paragraph._p.append(link)


def make_word(topic):
    from docx import Document
    o = get_outline(topic)
    doc = Document()
    doc.add_heading(o["title"], 0)
    doc.add_paragraph().add_run(f"Created by Jack on {dt.datetime.now():%d %B %Y}").italic = True
    for sec in o["sections"]:
        doc.add_heading(sec["heading"], 1)
        doc.add_paragraph(sec["points"][0])                       # first sentence = paragraph
        for p in sec["points"][1:]:                               # the rest = bullet points
            doc.add_paragraph(p, style="List Bullet")
    doc.add_heading("Conclusion", 1)
    for p in o["conclusion"]:
        doc.add_paragraph(p, style="List Bullet")
    path = new_path("Word", topic, "docx")
    doc.save(path)
    return path, f"{len(o['sections'])} sections, content from {o['source']}"


# ---------------------------------------------------------------- tables / data (used by Excel, Word table, chart)
def parse_table(text):
    """'Name,Age; Ali,20; Sara,22' -> (['Name','Age'], [['Ali',20],['Sara',22]]).  First row = headers."""
    def num(v):
        try:
            return int(v)
        except ValueError:
            try:
                return float(v)
            except ValueError:
                return v
    lines = [l.strip() for l in re.split(r"[;\n]", text) if l.strip()]
    if len(lines) == 1:                                           # one line: every item becomes a row
        return ["Item"], [[x.strip()] for x in lines[0].split(",") if x.strip()]
    rows = [[c.strip() for c in l.split(",")] for l in lines]
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    return rows[0], [[num(c) for c in r] for r in rows[1:]]


def _style_sheet(ws, headers, rows):
    from openpyxl.styles import Font, PatternFill, Alignment
    ws.append(headers)
    for r in rows:
        ws.append(r)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="3B6FF5")
        c.alignment = Alignment(horizontal="center")
    for col in ws.columns:                                        # auto column width
        width = max(len(str(c.value or "")) for c in col)
        ws.column_dimensions[col[0].column_letter].width = min(max(width + 3, 10), 70)
    ws.freeze_panes = "A2"


def _add_chart(ws, n_rows):
    """Small bar chart when column B holds numbers."""
    from openpyxl.chart import BarChart, Reference
    if n_rows >= 2 and all(isinstance(ws.cell(r, 2).value, (int, float)) for r in range(2, n_rows + 2)):
        ch = BarChart(); ch.title = ws.cell(1, 2).value
        ch.add_data(Reference(ws, min_col=2, min_row=1, max_row=n_rows + 1), titles_from_data=True)
        ch.set_categories(Reference(ws, min_col=1, min_row=2, max_row=n_rows + 1))
        ws.add_chart(ch, "E2")


# ---------------------------------------------------------------- Excel
def make_excel(arg):
    """excel <topic>  or  excel Name,Age; Ali,20; Sara,22"""
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active
    if ";" in arg or "\n" in arg:                                 # my own data
        headers, rows = parse_table(arg)
        ws.title = "Data"; _style_sheet(ws, headers, rows); _add_chart(ws, len(rows))
        info, name = f"{len(rows)} rows of your data", "Data"
    else:                                                         # a topic
        o = get_outline(arg)
        ws.title = "Overview"
        rows = [[i, sec["heading"], p] for i, sec in enumerate(o["sections"], 1) for p in sec["points"]]
        _style_sheet(ws, ["No", "Section", "Key point"], rows)
        info, name = f"{len(rows)} key points, content from {o['source']}", arg
    path = new_path("Excel", name, "xlsx")
    wb.save(path)
    return path, info


def record_excel(arg=""):
    """record  -> saves all notes and tasks.   record <data> -> saves the data you typed."""
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active
    if arg:
        headers, rows = parse_table(arg)
        ws.title = "Record"; _style_sheet(ws, headers, rows); _add_chart(ws, len(rows))
        info = f"{len(rows)} rows saved"
    else:
        notes = [[n["id"], n["text"], n["created"]] for n in reversed(store.rows("notes"))]
        todos = [[t["id"], t["text"], "Yes" if t["done"] else "No", t["created"]] for t in reversed(store.rows("todos"))]
        ws.title = "Notes"; _style_sheet(ws, ["ID", "Note", "Created"], notes)
        _style_sheet(wb.create_sheet("Tasks"), ["ID", "Task", "Done", "Created"], todos)
        info = f"{len(notes)} notes and {len(todos)} tasks saved"
    path = new_path("Record", arg or "notes_and_tasks", "xlsx")
    wb.save(path)
    return path, info


# ---------------------------------------------------------------- Word table, chart, diagram
def make_table(arg):
    from docx import Document
    headers, rows = parse_table(arg)
    doc = Document()
    doc.add_heading("Table", 1)
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    for i, h in enumerate(headers):
        t.rows[0].cells[i].text = str(h)
        t.rows[0].cells[i].paragraphs[0].runs[0].bold = True
    for r in rows:
        cells = t.add_row().cells
        for i, v in enumerate(r):
            cells[i].text = str(v)
    path = new_path("Table", headers[0], "docx")
    doc.save(path)
    return path, f"{len(rows)} rows"


def _plt():
    import matplotlib
    matplotlib.use("Agg")                                         # no window, just save a file
    import matplotlib.pyplot as plt
    return plt


def make_chart(kind, text):
    """chart sales: jan=10, feb=20, mar=15   (kind = bar / pie / line)"""
    title, _, data = text.partition(":")
    if not data:
        title, data = "Chart", text
    labels, values = [], []
    for item in data.split(","):
        m = re.match(r"\s*(.+?)\s*[=: ]\s*(-?\d+(?:\.\d+)?)\s*$", item)
        if m:
            labels.append(m.group(1)); values.append(float(m.group(2)))
    if len(values) < 2:
        raise ValueError("need at least 2 values")
    plt = _plt()
    fig, ax = plt.subplots(figsize=(8, 5))
    if kind == "pie":
        ax.pie(values, labels=labels, autopct="%1.0f%%", startangle=90)
    elif kind == "line":
        ax.plot(labels, values, marker="o", color="#3B6FF5", linewidth=2)
    else:
        ax.bar(labels, values, color="#3B6FF5")
    ax.set_title(title.strip().title(), fontsize=15)
    fig.tight_layout()
    path = new_path("Chart", title, "png")
    fig.savefig(path, dpi=150); plt.close(fig)
    return path, f"{kind} chart with {len(values)} values"


def make_diagram(text):
    """diagram login flow: start -> enter password -> check -> home"""
    from matplotlib.patches import FancyBboxPatch
    title, _, steps = text.partition(":")
    if "->" not in steps:
        title, steps = "Diagram", text
    steps = [s.strip() for s in re.split(r"->|→", steps) if s.strip()]
    if len(steps) < 2:
        raise ValueError("need at least 2 steps")
    per_row, w, h = 4, 2.1, 0.9
    rows = (len(steps) + per_row - 1) // per_row
    plt = _plt()
    fig, ax = plt.subplots(figsize=(11, 2.3 * rows + 0.8))
    ax.set_xlim(0, per_row * 2.6); ax.set_ylim(0, rows * 2); ax.axis("off")
    centers = []
    for i, step in enumerate(steps):                              # boxes in a snake layout
        r, c = divmod(i, per_row)
        c = per_row - 1 - c if r % 2 else c
        cx, cy = c * 2.6 + 1.3, (rows - 1 - r) * 2 + 1
        centers.append((cx, cy))
        ax.add_patch(FancyBboxPatch((cx - w / 2, cy - h / 2), w, h, boxstyle="round,pad=0.05", fc="#3B6FF5", ec="none"))
        ax.text(cx, cy, step, ha="center", va="center", color="white", fontsize=10, wrap=True)
    for (ax_, ay), (bx, by) in zip(centers, centers[1:]):         # arrows between boxes
        if ay == by:
            s = 1 if bx > ax_ else -1
            a, b = (ax_ + s * w / 2, ay), (bx - s * w / 2, by)
        else:
            a, b = (ax_, ay - h / 2), (bx, by + h / 2)
        ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="-|>", color="#555", lw=1.6))
    ax.set_title(title.strip().title(), fontsize=14)
    path = new_path("Diagram", title, "png")
    fig.savefig(path, dpi=150, bbox_inches="tight"); plt.close(fig)
    return path, f"diagram with {len(steps)} steps"
