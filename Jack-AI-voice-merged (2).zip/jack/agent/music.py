"""Play a song on YouTube: find the FIRST video for the search and open that video directly (autoplay).

The old code only opened the YouTube search page (youtube.com/results?search_query=...), so nothing played.
Order used here:  1) yt-dlp  ->  2) read the YouTube search page ourselves  ->  3) pywhatkit (only if installed)
"""
import os
import re
import webbrowser
from urllib.parse import quote_plus

from . import web


class NoInternet(Exception):
    """YouTube could not be reached."""


class NotFound(Exception):
    """YouTube answered, but there was no video for this search."""


def _watch_url(video_id):
    return f"https://www.youtube.com/watch?v={video_id}&autoplay=1"


def _with_yt_dlp(query):
    from yt_dlp import YoutubeDL                                # pip install yt-dlp
    opts = {"quiet": True, "no_warnings": True, "skip_download": True, "extract_flat": True,
            "noplaylist": True, "socket_timeout": 10}
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"ytsearch1:{query}", download=False)
    for entry in (info or {}).get("entries") or []:
        if entry and entry.get("id"):
            return entry["id"], entry.get("title") or query
    return None


def _with_search_page(query):
    page = web.get_text("https://www.youtube.com/results?search_query=" + quote_plus(query),
                        headers={**web.UA, "Accept-Language": "en-US,en;q=0.9"}, timeout=10)
    m = re.search(r'"videoRenderer":\{"videoId":"([\w-]{11})"', page) or re.search(r'"videoId":"([\w-]{11})"', page)
    return (m.group(1), query) if m else None


def _with_pywhatkit(query):
    import pywhatkit                                            # optional: pip install pywhatkit
    pywhatkit.playonyt(query)                                   # opens the browser by itself
    return "opened", query


def find_video(query):
    """Returns (video_id, title). Raises NoInternet or NotFound."""
    internet_error = None
    for finder in (_with_yt_dlp, _with_search_page, _with_pywhatkit):
        try:
            hit = finder(query)
            if hit:
                return hit
        except ImportError:
            continue                                            # that helper is not installed: try the next one
        except Exception as e:
            text = f"{type(e).__name__} {e}".lower()
            if any(w in text for w in ("urlerror", "timeout", "timed out", "connection", "resolve", "network", "getaddrinfo", "unreachable")):
                internet_error = e
    if internet_error:
        raise NoInternet(str(internet_error))
    raise NotFound(query)


def play(query):
    """Finds the song and opens it. Returns (url, opened_on_this_computer)."""
    video_id, _title = find_video(query)
    if video_id == "opened":                                    # pywhatkit already opened the browser
        return "https://www.youtube.com/results?search_query=" + quote_plus(query), True
    url = _watch_url(video_id)
    opened = False
    if not os.getenv("JACK_NO_BROWSER"):
        try:
            opened = bool(webbrowser.open(url))                 # starts playing in your own browser
        except Exception:
            opened = False
    return url, opened
