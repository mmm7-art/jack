"""Understands 'play a song' and 'show me jobs' in English, Urdu and Sindhi
(native script and Roman letters). Everything is matched on a simplified form of the text
(see lang.norm) so Urdu and Sindhi spellings of the same word both work.

    song_request("play believer")              -> "believer"
    song_request("believer chalao")            -> "believer"
    song_request("gaano wajao tum hi ho")      -> "tum hi ho"
    song_request("گانا چلاؤ تم ہی ہو")          -> "تم ہی ہو"
    song_request("hello there")                -> None   (not a song request)
    song_request("bajao")                      -> ""     (song request, but no name)

    is_jobs("naukri dikhao") / is_jobs("نوکری دکھاؤ") / is_jobs("jobs") -> True
"""
import re
from .lang import norm

_TOKEN = re.compile(r"[\w\u0600-\u06FF]+(?:['’\-][\w\u0600-\u06FF]+)*", re.UNICODE)


def _set(*words):
    return {norm(w) for w in words}


# ------------------------------------------------------------------ words for "play a song"
_STRONG_NATIVE = _set("چلاؤ", "چلا", "چلائیں", "چلایو", "بجاؤ", "بجا", "بجائیں", "وڄاءِ", "وڄايو",
                      "هلاءِ", "هلايو", "پلے", "پلي", "پلی")
_STRONG_ROMAN = re.compile(r"^(chal|baj|waj|hal)a+(o+|do|de|na|ye|iye|en|ain)?$")
_WEAK = _set("sunao", "sunaao", "suna", "sunna", "sunado", "lagao", "laga", "lagado", "lagade", "lagaiye",
             "سناؤ", "سنا", "سنائیں", "لگاؤ", "لگا", "لگايو", "ٻڌاءِ", "ٻڌايو", "ٻڌائو")
_SONG = _set("gaana", "gana", "gaane", "gane", "gaano", "gano", "gaanu", "ganu", "gaani", "gaanay", "ganay", "gaanon",
             "ganon", "geet", "geeton", "song", "songs", "music", "naghma", "tune", "track",
             "گانا", "گانے", "گانو", "گانی", "گانن", "گانوں", "گیت", "گیتن", "نغمہ", "گاني", "ڳاڻو")
_SONG_RE = re.compile(r"^ga+n[aeiou]+$")
_GREET = _set("jack", "jak", "hey", "hi", "hello", "ok", "okay", "جیک", "جيڪ", "ہیلو", "هيلو")
_PRE = _set("mujhe", "mere", "meri", "mera", "mon", "mukhe", "ek", "aik", "ik", "ye", "yeh", "wo", "zara", "please", "plz", "pls",
            "مجھے", "میرے", "ایک", "یہ", "زرا", "پلیز", "مون", "مونکھی", "هڪ")
_POST = _set("do", "de", "dena", "den", "dijiye", "dijye", "karo", "kar", "kro", "please", "plz", "pls", "zara", "jaldi", "mehrbani",
             "دو", "دیں", "دے", "دیجیے", "دیجئے", "کرو", "کر", "کریں", "پلیز", "زرا", "مہربانی",
             "ڏيو", "ڏي", "ڪر", "ڪريو", "مهرباني", "dio", "diyo", "kayo", "karyo")
_TRAIL = _POST | _set("youtube", "yt", "par", "pe", "per", "py", "on", "te", "tay", "pr",
                      "یوٹیوب", "يوٽيوب", "پر", "پہ", "تی", "تي")
_RIGHT_JUNK = _set("ka", "ki", "ke", "ko", "wala", "wali", "wale", "ek", "aik", "ye", "yeh", "jo", "je",
                   "کا", "کی", "کے", "کو", "والا", "والی", "جو", "جي", "جو")
_LEFT_ARTICLES = _set("a", "an", "the", "some")


def _is_strong(n):
    return n == "play" or n in _STRONG_NATIVE or bool(_STRONG_ROMAN.match(n))


def _is_song(n):
    return n in _SONG or bool(_SONG_RE.match(n))


def song_request(text):
    """Returns the song name (may be '' if no name was given) or None if this is not a song request."""
    toks = _TOKEN.findall(text or "")
    if not toks or len(toks) > 14:
        return None
    nt = [norm(t) for t in toks]
    n = len(toks)

    # ---- form 1: [greeting] [song word] verb [fillers] NAME      e.g. "play believer", "gaana chalao believer"
    i = 0
    while i < n and nt[i] in _GREET:
        i += 1
    j, seen_song = i, False
    while j < n and (nt[j] in _PRE or _is_song(nt[j])):
        seen_song = seen_song or _is_song(nt[j])
        j += 1
    if j < n and (_is_strong(nt[j]) or (nt[j] in _WEAK and (seen_song or (j + 1 < n and _is_song(nt[j + 1]))))):
        j += 1
        while j < n and nt[j] in _POST:
            j += 1
        if j + 1 < n and nt[j] in _LEFT_ARTICLES and _is_song(nt[j + 1]):      # "play the song believer"
            j += 2
        elif j + 1 < n and _is_song(nt[j]):                                       # "play gaana believer"
            j += 1
        end = n
        while end > j and nt[end - 1] in _TRAIL:
            end -= 1
        return " ".join(toks[j:end]).strip()

    # ---- form 2: NAME [song word] verb [fillers]                 e.g. "believer chalao", "tum hi ho bajao do"
    k = n
    while k > 0 and nt[k - 1] in _POST | _set("youtube", "par", "pe", "per", "on", "te", "یوٹیوب", "پر", "پہ"):
        k -= 1
    consumed_filler = k < n
    if k > 0:
        v = nt[k - 1]
        english_play_alone = v == "play" and not consumed_filler        # "I saw him play" is not a command
        if (_is_strong(v) and not english_play_alone) or (v in _WEAK and k > 1 and _is_song(nt[k - 2])):
            k -= 1
            while k > 0 and (_is_song(nt[k - 1]) or nt[k - 1] in _RIGHT_JUNK):
                k -= 1
            s = 0
            while s < k and (nt[s] in _GREET or nt[s] in _PRE):
                s += 1
            return " ".join(toks[s:k]).strip()
    return None


# ------------------------------------------------------------------ words for "jobs"
_JOB = _set("job", "jobs", "jobz", "naukri", "naukriyan", "naukriyaan", "naukriyun", "naukriyoon", "naukari", "nokri",
            "nokrri", "naukrian", "rozgar", "rozgaar", "malazmat", "malazmatein",
            "جاب", "جابز", "نوکری", "نوکریاں", "نوکریوں", "نوکریون", "نوڪري", "نوڪرين", "نوڪريون", "نوڪريءَ", "ملازمت",
            "ملازمتیں", "روزگار")
_JOB_FILL = _set("show", "me", "dikhao", "dikha", "dikhaao", "dikhado", "dikhade", "batao", "bata", "do", "de", "dena",
                 "mujhe", "mere", "meri", "mera", "chahiye", "chahye", "chaiye", "search", "find", "get", "karo", "kar", "kro",
                 "please", "plz", "pls", "software", "engineering", "engineer", "developer", "pakistan", "in", "for", "ki", "ka",
                 "ke", "list", "report", "nikalo", "dhundo", "dhoondo", "talash", "new", "latest", "naye", "nayi", "wali",
                 "wala", "aur", "mein", "hain", "hai", "aaj", "today", "koi", "kuch", "some", "the", "a", "all", "sab", "sari",
                 "mukhe", "mon", "khe", "lai", "laai", "dio", "diyo", "dikhar", "dekhar", "deekhar", "joyi", "ahe", "aahe",
                 "jack", "hey", "hi", "hello",
                 "دکھاؤ", "دکھا", "دکھائیں", "بتاؤ", "بتا", "دو", "دیں", "دے", "چاہیے", "چاہئے", "مجھے", "میری", "میرے",
                 "تلاش", "کرو", "کریں", "کی", "کا", "کے", "سافٹ", "ویئر", "سافٹویئر", "انجینئر", "انجینئرنگ", "پاکستان",
                 "میں", "لسٹ", "رپورٹ", "نکالو", "ڈھونڈو", "نئی", "نئے", "کوئی", "کچھ", "سب", "پلیز", "جیک",
                 "ڏيکار", "ڏيکاريو", "ڏيو", "ڏي", "ڏسو", "مون", "مونکي", "کي", "لاءِ", "جي", "جو", "ڪا", "ڪي", "گهرجي",
                 "ڳولي", "ڳولهيو", "ڪريو", "ڪر", "پاڪستان", "۾", "هڪ", "ڪجهه", "سڀ")


def is_jobs(text):
    """True when the message is a request to show jobs (any of the three languages)."""
    nt = [norm(t) for t in _TOKEN.findall(text or "")]
    if not nt or len(nt) > 8:
        return False
    if nt[0] in _JOB:                                   # "jobs ...", "naukri ...", "نوکری ..."
        return True
    return any(t in _JOB for t in nt) and all(t in _JOB or t in _JOB_FILL for t in nt)
