"""Jack's brain: rule-based command router + optional Claude AI fallback."""
import re, random, math, os, platform, secrets, string, datetime as dt
import urllib.parse
from . import store, web, ai, documents, jobs, music, lang, intents

JOKES = ["Why do programmers prefer dark mode? Because light attracts bugs.",
         "There are 10 types of people: those who understand binary and those who don't.",
         "A SQL query walks into a bar, sees two tables and asks: can I join you?",
         "Debugging: being the detective in a crime movie where you are also the murderer."]
QUOTES = ["Talk is cheap. Show me the code. - Linus Torvalds",
          "First, solve the problem. Then, write the code. - John Johnson",
          "Simplicity is the soul of efficiency. - Austin Freeman",
          "Make it work, make it right, make it fast. - Kent Beck"]
SITES = {"youtube": "https://youtube.com", "google": "https://google.com", "github": "https://github.com",
         "whatsapp": "https://web.whatsapp.com", "gmail": "https://mail.google.com",
         "linkedin": "https://linkedin.com", "chatgpt": "https://chat.openai.com",
         "claude": "https://claude.ai", "instagram": "https://instagram.com",
         "stackoverflow": "https://stackoverflow.com"}
HELP = ("Jack commands:\n"
        "- time / date\n- weather in <city>\n- wiki <topic>\n- play <song>  (opens the first YouTube video and plays it)\n- open <site>\n"
        "- calc 12*(3+4)\n- note <text> | notes | delete note <id>\n- todo <text> | todos | done <id>\n"
        "- joke | quote | flip coin | roll dice | password [length]\n- system info\n"
        "- zip / unzip: use the Files panel\n"
        "\nDocuments (saved in Desktop/Jack Output):\n"
        "- ppt on <topic>  -> PowerPoint\n"
        "- word on <topic>  or  make word document about <topic>  -> Word\n"
        "- excel <topic>  or  excel Name,Age; Ali,20; Sara,22  -> Excel\n"
        "- record  (all notes + tasks)  or  record Item,Price; Milk,200  -> Excel\n"
        "- chart sales: jan=10, feb=20, mar=15  (bar chart; also: pie chart / line chart)\n"
        "- table Name,Age; Ali,20; Sara,22  -> Word table\n"
        "- diagram login: start -> password -> check -> home\n"
        "\nJobs (Google Jobs via SerpApi):\n"
        "- jobs  /  naukri  /  job dikhao  -> Software_Jobs_Report.docx on your Desktop\n"
        "\nLanguages: English, Urdu and Sindhi (script or Roman letters). Jack replies in the language you use.\n"
        "- play: play / chalao / bajao / gaano wajao <song>     - jobs: jobs / naukri / نوکری\n"
        "- anything else is answered by the AI (needs ANTHROPIC_API_KEY in .env)")


def safe_calc(expr):
    if not re.fullmatch(r"[0-9+\-*/().%^ ,a-z]*", expr):
        raise ValueError("bad characters")
    names = {k: getattr(math, k) for k in ("sqrt", "sin", "cos", "tan", "log", "pi", "e", "floor", "ceil")}
    return eval(expr.replace("^", "**"), {"__builtins__": {}}, names)


def weather(city):
    g = web.get_json("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + urllib.parse.quote(city))
    if not g.get("results"):
        return f"City '{city}' not found."
    p = g["results"][0]
    w = web.get_json("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
                     "&current=temperature_2m,wind_speed_10m,relative_humidity_2m" % (p["latitude"], p["longitude"]))["current"]
    return (f"{p['name']}, {p.get('country', '')}: {w['temperature_2m']}°C, "
            f"humidity {w['relative_humidity_2m']}%, wind {w['wind_speed_10m']} km/h")


def wiki(topic):
    d = web.get_json("https://en.wikipedia.org/api/rest_v1/page/summary/" + urllib.parse.quote(topic.replace(" ", "_")))
    return d.get("extract", "No summary found.")


def handle(text):
    """Returns {reply, action?, file?, link?}. The browser runs 'action' (open a link) and shows 'file'/'link' as buttons."""
    t = (text or "").strip()[:500]
    store.log("user", t)
    out = _route(t, t.lower(), lang.detect(t))
    store.log("jack", out["reply"])
    return out


# ---------- helpers for the new document commands ----------
def _file_reply(path, info, what):
    """Reply that shows the saved path and a download button."""
    return {"reply": f"{what} created ({info}).\nSaved here:\n{path}",
            "file": {"name": path.name, "url": "/api/output/" + path.name}}


def _make(fn, what, *args):
    try:
        path, info = fn(*args)
        return _file_reply(path, info, what)
    except Exception as e:
        return {"reply": f"Sorry, I couldn't create the {what.lower()}: {e}"}


def _documents(t, low):
    """Handles ppt / word / excel / record / chart / table / diagram. Returns None if no match."""
    m = re.match(r"(?:make (?:a |an )?)?(?:ppt|pptx|powerpoint|presentation)(?:\s+(?:on|about))?\s+(.+)", t, re.I)
    if m:
        return _make(documents.make_ppt, "PowerPoint", m.group(1).strip())
    m = re.match(r"(?:make (?:a |an )?)?(?:word|docx)(?:\s+(?:document|doc))?(?:\s+(?:on|about))?\s+(.+)", t, re.I)
    if m:
        return _make(documents.make_word, "Word document", m.group(1).strip())
    m = re.match(r"(?:excel\s+)?record\b\s*(.*)", t, re.I)
    if m:
        return _make(documents.record_excel, "Excel record", m.group(1).strip())
    m = re.match(r"(?:make (?:a |an )?)?(?:excel|xlsx|spreadsheet)(?:\s+(?:on|about|for))?\s+(.+)", t, re.I)
    if m:
        return _make(documents.make_excel, "Excel file", m.group(1).strip())
    m = re.match(r"(?:make (?:a |an )?)?(?:(bar|pie|line)\s+)?chart\s+(.+)", t, re.I)
    if m:
        kind = (m.group(1) or "bar").lower()
        if len(m.group(2)) < 5:
            return {"reply": "Try: chart sales: jan=10, feb=20, mar=15"}
        return _make(documents.make_chart, "Chart", kind, m.group(2))
    m = re.match(r"(?:make (?:a |an )?)?table\s+(.+)", t, re.I)
    if m:
        return _make(documents.make_table, "Table", m.group(1))
    m = re.match(r"(?:make (?:a |an )?)?diagram\s+(.+)", t, re.I)
    if m:
        return _make(documents.make_diagram, "Diagram", m.group(1))
    return None


def _jobs(t, lg):
    """Any 'show me jobs' request in English / Urdu / Sindhi. Uses SerpApi Google Jobs (see agent/jobs.py)."""
    if not intents.is_jobs(t):
        return None
    try:
        path, count = jobs.run()
    except jobs.NoKey:
        return {"reply": lang.tr("jobs_no_key", lg)}
    except jobs.JobsError as e:
        return {"reply": lang.tr("jobs_error", lg, why=str(e))}
    except Exception as e:                                       # never crash the website
        return {"reply": lang.tr("jobs_error", lg, why=f"{type(e).__name__}")}
    if not count:
        return {"reply": lang.tr("jobs_none", lg)}
    return {"reply": lang.tr("jobs_ok", lg, n=count, path=path),
            "file": {"name": os.path.basename(path), "url": "/api/jobs-report"}}


def _play(t, lg):
    """Any 'play a song' request in English / Urdu / Sindhi: opens the first YouTube video and plays it."""
    name = intents.song_request(t)
    if name is None:
        return None
    if not name:
        return {"reply": lang.tr("play_need_name", lg)}
    try:
        url, opened = music.play(name)
    except music.NoInternet:
        return {"reply": lang.tr("play_offline", lg)}
    except music.NotFound:
        return {"reply": lang.tr("play_not_found", lg, name=name)}
    except Exception:
        return {"reply": lang.tr("play_offline", lg)}
    out = {"reply": lang.tr("play_ok", lg, name=name), "link": {"label": "Open video again", "url": url}}
    if not opened:                                               # server could not open a browser: let the web page do it
        out["action"] = {"type": "open", "url": url}
    return out


def _ai(t, lg):
    """Anything that is not a built-in command goes to Claude. Clear, simple messages when it cannot answer."""
    try:
        ans = ai.ask(t)
    except ai.AIError as e:
        return {"reply": lang.tr("ai_error", lg, why=str(e))}
    except Exception as e:
        return {"reply": lang.tr("ai_error", lg, why=type(e).__name__)}
    return {"reply": ans or lang.tr("ai_no_key", lg)}


def _route(t, low, lg="en"):
    if not low:
        return {"reply": "Say something, sir."}
    if low in ("hi", "hello", "hey", "hello jack", "hi jack"):
        return {"reply": "Yes sir, I'm listening. Type 'help' to see what I can do."}
    if low == "help":
        return {"reply": HELP}
    if low in ("time", "what time is it"):
        return {"reply": dt.datetime.now().strftime("It's %I:%M %p")}
    if low in ("date", "today"):
        return {"reply": dt.datetime.now().strftime("Today is %A, %d %B %Y")}
    if low == "joke":
        return {"reply": random.choice(JOKES)}
    if low == "quote":
        return {"reply": random.choice(QUOTES)}
    if low in ("flip coin", "flip a coin"):
        return {"reply": random.choice(["Heads", "Tails"])}
    if low in ("roll dice", "roll a dice"):
        return {"reply": f"You rolled a {random.randint(1, 6)}"}
    if low in ("system info", "system"):
        return {"reply": f"{platform.system()} {platform.release()} | Python {platform.python_version()} | {platform.machine()}"}
    m = re.fullmatch(r"password\s*(\d+)?", low)
    if m:
        n = min(max(int(m.group(1) or 14), 8), 64)
        chars = string.ascii_letters + string.digits + "!@#$%&*"
        return {"reply": "".join(secrets.choice(chars) for _ in range(n))}
    m = re.match(r"(?:calc|calculate)\s+(.+)", low)
    if m:
        try:
            return {"reply": f"{m.group(1)} = {safe_calc(m.group(1))}"}
        except Exception:
            return {"reply": "I couldn't calculate that. Try: calc 12*(3+4)"}
    m = re.match(r"weather(?: in)?\s+(.+)", low)
    if m:
        try:
            return {"reply": weather(m.group(1))}
        except Exception:
            return {"reply": "Weather service is unreachable right now."}

    # ---- new: documents and job research (checked before wiki / AI) ----
    out = _jobs(t, lg) or _documents(t, low)
    if out:
        return out

    m = re.match(r"(?:wiki|who is|what is)\s+(.+)", low)
    if m:
        try:
            return {"reply": wiki(m.group(1))}
        except Exception:
            pass
    out = _play(t, lg)
    if out:
        return out
    m = re.match(r"open\s+(.+)", low)
    if m:
        name = m.group(1).strip()
        url = SITES.get(name) or (f"https://{name}" if re.fullmatch(r"[\w-]+(\.[\w-]+)+", name)
                                  else f"https://www.google.com/search?q={urllib.parse.quote(name)}")
        return {"reply": f"Opening {name}.", "action": {"type": "open", "url": url}}
    m = re.match(r"note\s+(.+)", t, re.I)
    if m:
        return {"reply": f"Note #{store.add('notes', m.group(1))} saved."}
    if low == "notes":
        n = store.rows("notes")
        return {"reply": "\n".join(f"#{x['id']} {x['text']}" for x in n) or "No notes yet."}
    m = re.match(r"delete note\s+(\d+)", low)
    if m:
        return {"reply": "Deleted." if store.delete("notes", int(m.group(1))) else "Note not found."}
    m = re.match(r"todo\s+(.+)", t, re.I)
    if m:
        return {"reply": f"Task #{store.add('todos', m.group(1))} added."}
    if low in ("todos", "tasks"):
        n = store.rows("todos")
        return {"reply": "\n".join(f"#{x['id']} [{'x' if x['done'] else ' '}] {x['text']}" for x in n) or "No tasks."}
    m = re.match(r"done\s+(\d+)", low)
    if m:
        return {"reply": "Marked done." if store.done(int(m.group(1))) else "Task not found."}
    return _ai(t, lg)
