"""Claude AI helper. Uses the official `anthropic` library and reads ANTHROPIC_API_KEY from the environment
(the key lives in the .env file, which app.py loads with python-dotenv at the very top)."""
import os

SYSTEM = ("You are Jack, a concise, friendly personal AI agent. "
          "You understand only English, Urdu and Sindhi, including Roman Urdu and Roman Sindhi. "
          "Always reply in the same language and script the user used. If the user writes in Sindhi, reply in Sindhi. "
          "If the user writes in Urdu, reply in Urdu. "
          "If the user mixes languages in one sentence, reply in the same mix. "
          "Do not use any other language.")


class AIError(Exception):
    """The AI call failed. The message is short, simple English and is safe to show to the user."""


def has_key():
    return bool((os.getenv("ANTHROPIC_API_KEY") or "").strip())


def ask(prompt, system=None, max_tokens=500, timeout=30):
    """Returns the AI text, or None when there is no API key. Raises AIError when the call fails.
    `system` is only given by internal callers (e.g. the PowerPoint writer needs JSON only)."""
    key = (os.getenv("ANTHROPIC_API_KEY") or "").strip()
    if not key:
        return None
    try:
        import anthropic
    except ImportError:
        raise AIError("the 'anthropic' library is not installed (run: pip install -r requirements.txt)")
    try:
        client = anthropic.Anthropic(api_key=key, timeout=timeout, max_retries=1)
        msg = client.messages.create(model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"), max_tokens=max_tokens,
                                     system=system or SYSTEM, messages=[{"role": "user", "content": prompt}])
    except anthropic.AuthenticationError:
        raise AIError("the ANTHROPIC_API_KEY is not valid")
    except anthropic.PermissionDeniedError:
        raise AIError("this API key is not allowed to use this model")
    except anthropic.NotFoundError:
        raise AIError("the model name is wrong (check ANTHROPIC_MODEL in .env)")
    except anthropic.RateLimitError:
        raise AIError("too many requests, please wait a minute")
    except anthropic.APIConnectionError:
        raise AIError("no internet connection to the AI")
    except anthropic.APIStatusError as e:
        raise AIError(f"the AI service returned error {e.status_code}")
    text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
    if not text:
        raise AIError("the AI sent an empty answer")
    return text
