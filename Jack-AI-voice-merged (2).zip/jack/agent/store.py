"""SQLite storage: notes, todos and chat history (agent memory)."""
import sqlite3, os

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "jack.db")
TABLES = {"notes", "todos", "history"}


def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, text TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS todos(id INTEGER PRIMARY KEY, text TEXT, done INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY, text TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        """)


def _check(table):
    if table not in TABLES:
        raise ValueError("bad table")


def add(table, text):
    _check(table)
    with conn() as c:
        return c.execute(f"INSERT INTO {table}(text) VALUES(?)", (text,)).lastrowid


def rows(table):
    _check(table)
    with conn() as c:
        return [dict(r) for r in c.execute(f"SELECT * FROM {table} ORDER BY id DESC")]


def delete(table, i):
    _check(table)
    with conn() as c:
        return c.execute(f"DELETE FROM {table} WHERE id=?", (i,)).rowcount


def done(i):
    with conn() as c:
        return c.execute("UPDATE todos SET done=1 WHERE id=?", (i,)).rowcount


def log(role, text):
    add("history", f"{role}: {text}")
