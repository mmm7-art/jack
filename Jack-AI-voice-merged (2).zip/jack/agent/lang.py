"""Language helpers for Jack. Only three languages are supported: English, Urdu and Sindhi
(each in its own script AND in Roman letters).

detect(text) returns one of:  "en"  "ur"  "ur_ar"  "sd"  "sd_ar"
    ur = Roman Urdu,  ur_ar = Urdu script,  sd = Roman Sindhi,  sd_ar = Sindhi script
tr(key, lang, **values) returns the ready-made reply text in that language.
"""
import re
import unicodedata

# ---------------------------------------------------------------- text normalising
# Urdu and Sindhi share the Arabic script but spell some letters differently.
# We map every variant to one simple form so that matching works for both languages.
_MAP = {
    "ي": "ی", "ى": "ی", "ے": "ی", "ې": "ی",           # all yeh forms
    "ك": "ک", "ڪ": "ک",                                 # kaf forms (ڪ is Sindhi)
    "ه": "ہ", "ھ": "ہ", "ۃ": "ہ", "ة": "ہ",             # heh forms
    "ؤ": "و", "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
    "ں": "ن", "ڻ": "ن", "ڱ": "ن", "ڃ": "ن",
    "ٺ": "ٹ", "ٽ": "ٹ", "ٿ": "ت", "ٻ": "ب", "ڀ": "ب",
    "ڄ": "ج", "ڃ": "ن", "ڇ": "چ", "ڌ": "د", "ڏ": "د", "ڊ": "ڈ", "ڍ": "ڈ",
    "ڙ": "ر", "ڑ": "ر", "ڦ": "پ", "ڳ": "گ", "ڱ": "ن",
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
}
_DROP = dict.fromkeys(map(ord, "ءًٌٍَُِّْٰٔ٘ـ\u200c\u200d\u200e\u200f"), None)   # marks, hamza, zero-width
_TABLE = {**{ord(k): v for k, v in _MAP.items()}, **_DROP}
_ARABIC = re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]")
_WORD = re.compile(r"[\w\u0600-\u06FF]+", re.UNICODE)

# Letters that exist in Sindhi but not in Urdu
_SINDHI_LETTERS = set("ڪڳڄڙڏٺٽڻڦڀڇڌڊڍڃڱٻٿ")
# Roman words that are clearly Sindhi (not Urdu)
_SINDHI_ROMAN = {"wajao", "wajaao", "waja", "halao", "halaao", "gaano", "gaanu", "mukhe", "aahe", "ahe", "aahiyan",
                 "chao", "kehro", "kithe", "athe", "tunhinjo", "pahnji", "pahnjo", "thi", "thiyo", "ahyan", "aahyan",
                 "dikhar", "deekhar", "kando", "kandi", "kayo", "karyo", "joyi", "gaanan", "naalo", "maan"}
# Roman words that are clearly Urdu (or Roman Urdu)
_URDU_ROMAN = {"chalao", "chalaao", "bajao", "bajaao", "dikhao", "dikha", "batao", "suna", "sunao", "mujhe", "mera",
               "meri", "hai", "hain", "karo", "kar", "dena", "naukri", "nokri", "gaana", "gana", "kya", "kaise",
               "kaun", "kahan", "aap", "tum", "mein", "ko", "ki", "ka", "ke", "chahiye", "chahye", "acha",
               "theek", "shukriya", "jawab", "bolo", "likho", "abhi", "nahi", "haan"}


def norm(text):
    """Lower-case, unify Urdu/Sindhi letter variants, drop marks. Used only for matching."""
    text = unicodedata.normalize("NFKC", text or "").lower()
    return text.translate(_TABLE).strip()


def tokens(text):
    return _WORD.findall(norm(text))


def has_arabic_script(text):
    return bool(_ARABIC.search(text or ""))


def detect(text):
    """Guess the language + script of one message."""
    text = text or ""
    if has_arabic_script(text):
        letters = set(text)
        return "sd_ar" if letters & _SINDHI_LETTERS else "ur_ar"
    words = set(_WORD.findall(text.lower()))
    sd, ur = len(words & _SINDHI_ROMAN), len(words & _URDU_ROMAN)
    if sd and sd >= ur:
        return "sd"
    if ur:
        return "ur"
    return "en"


# ---------------------------------------------------------------- translated replies
# Order inside every tuple: en, ur (Roman Urdu), ur_ar (Urdu script), sd (Roman Sindhi), sd_ar (Sindhi script)
_ORDER = ("en", "ur", "ur_ar", "sd", "sd_ar")
T = {
    "play_ok": (
        "Playing '{name}' on YouTube for you. 🎵",
        "'{name}' YouTube par chala raha hoon. 🎵",
        "'{name}' یوٹیوب پر چلا رہا ہوں۔ 🎵",
        "Maan '{name}' YouTube te wajaayi rahyo aahiyan. 🎵",
        "مان '{name}' يوٽيوب تي وڄائي رهيو آهيان. 🎵"),
    "play_need_name": (
        "Which song should I play? Say: play <song name>",
        "Kaun sa gaana chalaun? Aise bolo: play <gaane ka naam>",
        "کون سا گانا چلاؤں؟ ایسے بولیں: play <گانے کا نام>",
        "Kehro gaano wajaayaan? Ihari tarah chao: play <gaane jo naalo>",
        "ڪهڙو گانو وڄايان؟ هيئن چئو: play <گاني جو نالو>"),
    "play_not_found": (
        "I couldn't find a video for '{name}'. Please try a different song name.",
        "'{name}' ki video nahi mili. Gaane ka naam badal kar dobara try karo.",
        "'{name}' کی ویڈیو نہیں ملی۔ گانے کا نام بدل کر دوبارہ کوشش کریں۔",
        "'{name}' jo video na milyo. Gaane jo naalo badaayi dobaaro koshish karyo.",
        "'{name}' جو وڊيو نه مليو. گاني جو نالو بدلائي ٻيهر ڪوشش ڪريو."),
    "play_offline": (
        "I can't reach YouTube. Please check your internet connection and try again.",
        "YouTube tak nahi pahunch pa raha. Apna internet check karo aur dobara try karo.",
        "یوٹیوب تک رسائی نہیں ہو رہی۔ اپنا انٹرنیٹ چیک کریں اور دوبارہ کوشش کریں۔",
        "YouTube tak pahchi na saghyo. Pahnjo internet check karyo ain dobaaro koshish karyo.",
        "يوٽيوب تائين پهچي نه سگهيو. پنهنجو انٽرنيٽ چيڪ ڪريو ۽ ٻيهر ڪوشش ڪريو."),
    "jobs_ok": (
        "Found {n} jobs for 'software engineer Pakistan'. 💼\nWord report saved here:\n{path}",
        "'software engineer Pakistan' ki {n} jobs mil gayin. 💼\nWord report yahan save ho gayi:\n{path}",
        "'software engineer Pakistan' کی {n} نوکریاں ملیں۔ 💼\nورڈ رپورٹ یہاں محفوظ ہو گئی:\n{path}",
        "'software engineer Pakistan' jun {n} naukriyun miliyun. 💼\nWord report hitey mehfooz thi wayi:\n{path}",
        "'software engineer Pakistan' جون {n} نوڪريون مليون. 💼\nورڊ رپورٽ هتي محفوظ ٿي وئي:\n{path}"),
    "jobs_none": (
        "No jobs came back right now. Please try again a little later.",
        "Abhi koi job nahi mili. Thori der baad dobara try karo.",
        "ابھی کوئی نوکری نہیں ملی۔ تھوڑی دیر بعد دوبارہ کوشش کریں۔",
        "Hinye wakht koi naukri na mili. Thorey wakht khaan pooey dobaaro koshish karyo.",
        "هن وقت ڪا نوڪري نه ملي. ٿوري دير کان پوءِ ٻيهر ڪوشش ڪريو."),
    "jobs_no_key": (
        "The job search needs a SerpApi key.\n1) Open the .env file\n2) Write: SERPAPI_KEY=your_key\n3) Start again: python app.py",
        "Jobs ke liye SerpApi key chahiye.\n1) .env file kholo\n2) Likho: SERPAPI_KEY=apni_key\n3) Dobara chalao: python app.py",
        "نوکریوں کے لیے SerpApi کی key چاہیے۔\n1) .env فائل کھولیں\n2) لکھیں: SERPAPI_KEY=آپ_کی_key\n3) دوبارہ چلائیں: python app.py",
        "Naukriyun lai SerpApi jo key joyi.\n1) .env file kholyo\n2) Likho: SERPAPI_KEY=pahnji_key\n3) Dobaaro chalaayo: python app.py",
        "نوڪرين لاءِ SerpApi جي key گهرجي.\n1) .env فائل کوليو\n2) لکو: SERPAPI_KEY=پنهنجي_key\n3) ٻيهر هلايو: python app.py"),
    "jobs_error": (
        "The job search did not work: {why}. Please try again later.",
        "Job search nahi ho saki: {why}. Baad mein dobara try karo.",
        "نوکریوں کی تلاش نہیں ہو سکی: {why}۔ بعد میں دوبارہ کوشش کریں۔",
        "Naukriyun jo search na thi saghyo: {why}. Pooey dobaaro koshish karyo.",
        "نوڪرين جي ڳولا ٿي نه سگهي: {why}. پوءِ ٻيهر ڪوشش ڪريو."),
    "ai_no_key": (
        "I can't answer this yet because the AI key is missing.\n1) Open the .env file\n2) Write: ANTHROPIC_API_KEY=your_key\n3) Start again: python app.py\nUntil then, type 'help' to see what I can already do.",
        "Abhi main iska jawab nahi de sakta, kyunke AI key nahi mili.\n1) .env file kholo\n2) Likho: ANTHROPIC_API_KEY=apni_key\n3) Dobara chalao: python app.py\nTab tak 'help' likho aur dekho main kya kya kar sakta hoon.",
        "ابھی میں اس کا جواب نہیں دے سکتا، کیونکہ AI key نہیں ملی۔\n1) .env فائل کھولیں\n2) لکھیں: ANTHROPIC_API_KEY=آپ_کی_key\n3) دوبارہ چلائیں: python app.py\nتب تک 'help' لکھیں اور دیکھیں میں کیا کیا کر سکتا ہوں۔",
        "Hinye wakht maan inja jawab kon ditho saghan, chaajo ta AI key na milyo.\n1) .env file kholyo\n2) Likho: ANTHROPIC_API_KEY=pahnji_key\n3) Dobaaro chalaayo: python app.py\nTad tain 'help' likho ain dekho maan chha chha kri saghan thao.",
        "هن وقت مان ان جو جواب ڏئي نه ٿو سگهان، ڇاڪاڻ ته AI key نه ملي.\n1) .env فائل کوليو\n2) لکو: ANTHROPIC_API_KEY=پنهنجي_key\n3) ٻيهر هلايو: python app.py\nتيستائين 'help' لکو ۽ ڏسو مان ڇا ڇا ڪري سگهان ٿو."),
    "ai_error": (
        "I couldn't get an AI answer right now: {why}.",
        "AI se jawab nahi aa saka: {why}.",
        "AI سے جواب نہیں مل سکا: {why}۔",
        "AI kaan jawaab na aayo: {why}.",
        "AI کان جواب نه آيو: {why}."),
}


def tr(key, lang="en", **values):
    row = T[key]
    text = row[_ORDER.index(lang)] if lang in _ORDER else row[0]
    return text.format(**values) if values else text
