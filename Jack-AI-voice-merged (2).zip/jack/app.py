"""Jack - Personal AI Agent (Flask backend)."""
# ---- Load the .env file FIRST, before anything else reads ANTHROPIC_API_KEY / SERPAPI_KEY ----
import os
from dotenv import load_dotenv                      # pip install python-dotenv
BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))             # always the .env that sits next to app.py
load_dotenv()                                       # also allow a .env in the folder you started Python from

import io, uuid, zipfile
from flask import Flask, jsonify, request, render_template, send_file, send_from_directory, abort, Response
from werkzeug.utils import secure_filename

from agent import commands, store, documents, jobs

UPLOADS = os.path.join(BASE, "uploads")
SITE_URL = os.getenv("SITE_URL", "http://localhost:5000").rstrip("/")

app = Flask(__name__)
app.json.ensure_ascii = False                        # send Urdu / Sindhi text as real UTF-8
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev")
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25 MB
os.makedirs(UPLOADS, exist_ok=True)
store.init()

META = {
    "title": "Jack - Personal AI Agent | Voice & Text Commands in Your Browser",
    "description": "Jack is a free personal AI agent for the web. Talk or type commands to play songs, check weather, take notes, manage tasks, zip files and ask AI.",
    "keywords": "personal AI agent, voice assistant, AI chatbot, Flask project, web engineering project, PWA",
}


@app.after_request
def security_headers(r):
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["X-Frame-Options"] = "SAMEORIGIN"
    r.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return r


# ---------- Pages ----------
@app.get("/")
def index():
    return render_template("index.html", meta=META, site_url=SITE_URL)


@app.get("/docs")
def docs():
    return render_template("docs.html", meta={**META, "title": "API Docs | Jack - Personal AI Agent"}, site_url=SITE_URL)


# ---------- REST API ----------
@app.get("/api/health")
def health():
    return jsonify(status="ok", ai_enabled=bool(os.getenv("ANTHROPIC_API_KEY")), jobs_enabled=bool(os.getenv("SERPAPI_KEY")))


@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    msg = data.get("message", "")
    if not isinstance(msg, str) or not msg.strip():
        return jsonify(error="message is required"), 400
    try:
        return jsonify(commands.handle(msg))
    except Exception as e:                      # never crash the chat: tell the user what happened
        return jsonify(reply=f"Sorry, something went wrong: {e}"), 200


@app.get("/api/history")
def history():
    return jsonify(store.rows("history")[:50])


@app.route("/api/<kind>", methods=["GET", "POST"])
def collection(kind):
    if kind not in ("notes", "todos"):
        abort(404)
    if request.method == "POST":
        text = (request.get_json(silent=True) or {}).get("text", "").strip()
        if not text:
            return jsonify(error="text is required"), 400
        return jsonify(id=store.add(kind, text[:500])), 201
    return jsonify(store.rows(kind))


@app.delete("/api/<kind>/<int:item_id>")
def remove(kind, item_id):
    if kind not in ("notes", "todos"):
        abort(404)
    return jsonify(deleted=bool(store.delete(kind, item_id)))


# ---------- Files: zip / unzip ----------
@app.post("/api/zip")
def make_zip():
    files = request.files.getlist("files")
    if not files:
        return jsonify(error="upload at least one file"), 400
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            name = secure_filename(f.filename or "")
            if name:
                z.writestr(name, f.read())
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True, download_name="jack-archive.zip")


@app.post("/api/unzip")
def unzip():
    f = request.files.get("file")
    if not f or not zipfile.is_zipfile(f):
        return jsonify(error="upload a valid .zip file"), 400
    f.seek(0)
    job = uuid.uuid4().hex[:10]
    dest = os.path.join(UPLOADS, job)
    os.makedirs(dest)
    out = []
    with zipfile.ZipFile(f) as z:
        for info in z.infolist()[:200]:
            name = secure_filename(os.path.basename(info.filename))  # blocks zip-slip
            if info.is_dir() or not name or info.file_size > 20 * 1024 * 1024:
                continue
            with open(os.path.join(dest, name), "wb") as fh:
                fh.write(z.read(info))
            out.append({"name": name, "size": info.file_size, "url": f"/api/files/{job}/{name}"})
    return jsonify(job=job, files=out)


@app.get("/api/files/<job>/<name>")
def get_file(job, name):
    if not job.isalnum():
        abort(404)
    return send_from_directory(os.path.join(UPLOADS, job), secure_filename(name), as_attachment=True)


# ---------- Jobs report (saved on the Desktop as Software_Jobs_Report.docx) ----------
@app.get("/api/jobs-report")
def jobs_report():
    path = jobs.report_path()
    if not os.path.isfile(path):
        return jsonify(error="No jobs report yet. Say 'jobs' in the chat first."), 404
    return send_file(path, as_attachment=True, download_name=jobs.REPORT_NAME)


# ---------- Files created by Jack (Desktop/Jack Output) ----------
@app.get("/api/output/<name>")
def get_output(name):
    return send_from_directory(documents.output_dir(), secure_filename(name), as_attachment=True)


@app.get("/api/outputs")
def list_outputs():
    folder = documents.output_dir()
    files = sorted(folder.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)[:30]
    return jsonify(folder=str(folder), files=[{"name": f.name, "url": "/api/output/" + f.name} for f in files if f.is_file()])


# ---------- SEO + PWA ----------
@app.get("/robots.txt")
def robots():
    return Response(f"User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: {SITE_URL}/sitemap.xml\n", mimetype="text/plain")


@app.get("/sitemap.xml")
def sitemap():
    urls = "".join(f"<url><loc>{SITE_URL}{p}</loc></url>" for p in ("/", "/docs"))
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>',
                    mimetype="application/xml")


@app.get("/sw.js")
def sw():
    return send_from_directory(os.path.join(BASE, "static"), "sw.js", mimetype="application/javascript")


@app.get("/manifest.json")
def manifest():
    return send_from_directory(os.path.join(BASE, "static"), "manifest.json", mimetype="application/manifest+json")


@app.errorhandler(404)
def nf(e):
    return (jsonify(error="not found"), 404) if request.path.startswith("/api/") else (render_template("index.html", meta=META, site_url=SITE_URL), 404)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
