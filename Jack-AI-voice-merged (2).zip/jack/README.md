# Jack - Personal AI Agent (Flask + SQLite + vanilla JS)

Talk or type commands in **English, Urdu or Sindhi**. Jack plays songs on YouTube, finds software jobs
(Word report on your Desktop), keeps notes and tasks, checks weather, creates PowerPoint / Word / Excel files,
and answers any other question with Claude AI.

## 1. Install (Windows)
Open **Command Prompt** inside the project folder (the folder that has `app.py`) and run:
```bat
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Set your keys in the `.env` file (Windows)
1. In the folder that has `app.py`, copy `.env.example` and rename the copy to `.env`
   (in File Explorer: View -> tick **File name extensions**, so it does not become `.env.txt`).
   Or in Command Prompt: `copy .env.example .env`
2. Open `.env` with Notepad and paste your keys after the `=` sign (no quotes, no spaces):
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
SERPAPI_KEY=xxxxxxxxxxxxxxxx
```
3. Save the file. If Jack is already running, stop it (Ctrl+C) and start it again.

* `ANTHROPIC_API_KEY` -> AI answers (https://console.anthropic.com)
* `SERPAPI_KEY` -> jobs search (https://serpapi.com, the free plan is enough to try it)

## 3. Run
```bat
python app.py
```
Open http://localhost:5000 in **Chrome or Edge** (voice input needs one of them).

## What Jack can do
| Say / type | What happens |
|---|---|
| `play believer` / `believer chalao` / `gaano wajao ...` | Finds the first YouTube video and plays it in your browser |
| `jobs` / `naukri` / `job dikhao` / `نوکری` | Google Jobs search -> `Software_Jobs_Report.docx` on your Desktop |
| anything else | Claude AI answers in the language you used (needs `ANTHROPIC_API_KEY`) |
| `ppt on <topic>`, `word on <topic>`, `excel ...`, `record`, `chart ...`, `table ...`, `diagram ...` | Files in Desktop/Jack Output |
| `weather in <city>`, `wiki <topic>`, `calc 2+2`, `joke`, `quote`, `password`, `time`, `date` | Quick answers |
| `note ...`, `notes`, `todo ...`, `todos`, `done 1`, `open youtube` | Notes, tasks, sites |

Voice: on the **Voice** page choose English / Urdu / Sindhi next to *Tap to speak* (Urdu is the default),
or type in the box beside it. Browsers support Sindhi voice only a little - if it fails, use Urdu or type.

Home page (first screen, beside the Jack orb): the room starts dark; pull the lamp chain (or click the lamp) and warm light falls on the "Instruction Diary", click the diary to open the ring-binder popup with 5 sections of Roman Urdu instructions (tap any example to copy it; close with the X button or Esc).

## Structure
```
app.py                 Flask app + REST API (loads .env first)
requirements.txt  .env.example
agent/commands.py      command router (the brain)
agent/intents.py       NEW  understands "play" and "jobs" in English / Urdu / Sindhi
agent/lang.py          NEW  language detection + translated replies
agent/jobs.py          REWRITTEN  SerpApi Google Jobs -> Word report
agent/music.py         NEW  first YouTube video -> opens and plays it
agent/ai.py            REWRITTEN  official anthropic library
agent/documents.py, web.py, store.py
templates/index.html, docs.html
static/css/style.css   themes, RTL fonts, lamp scene and Instruction Diary styles
static/js/app.js       pages, chat, voice (3 languages)
static/js/lamp.js      NEW  desk lamp + Instruction Diary popup (all instruction text lives here)
static/js/orb.js, static/sw.js, static/img/icon.svg
tests/test_api.py
```
Tests: `pytest -q tests`

## Enhanced voice session (merged)
The Voice page now includes Start voice, Mic on/muted, End voice, captions on/off, and Auto/English/Urdu/Sindhi language selection. Continuous listening sends recognized speech through the existing `/api/chat` command router, so existing Jack commands and command responses remain connected. Speech output uses the browser's available voices; the exact voice and quality depend on the browser and operating system.

## API key safety
Do not put API keys into frontend JavaScript or commit them into ZIP files. Add your own keys to a local `.env` file based on `.env.example`. If a key was shared in a chat or other public place, revoke it and create a replacement before using the project.
