/* Jack's 3D orb (Three.js).
   States: idle (slow spin) | thinking (fast spin + pulse) | listening (reacts to your voice) | speaking (soft pulse).
   If Three.js or WebGL is missing, a simple CSS orb is shown instead. */
window.JackOrb = (function () {
  const api = {
    state: "idle", level: 0, enabled: true, slot: null,
    setState(s) { this.state = s; document.body.dataset.orb = s; },
    setLevel(v) { this.level = v; },                 // 0..1 microphone loudness
    setEnabled(on) { this.enabled = on; if (this.slot) this.mount(this.slot); },
    recolor() {},
    mount(slot) {                                    // show the orb inside this slot
      this.slot = slot; slot.innerHTML = '<div class="css-orb"></div>';
    },
  };
  document.body.dataset.orb = "idle";
  if (typeof THREE === "undefined") return api;      // no Three.js -> CSS orb

  let renderer;
  try {
    const canvas = document.createElement("canvas");
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  } catch (e) { return api; }                        // no WebGL -> CSS orb
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));   // keeps it light on laptops

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 50);
  camera.position.z = 4.6;
  const group = new THREE.Group(); scene.add(group);

  const mat = (opacity, extra) => new THREE.MeshBasicMaterial(Object.assign({ transparent: true, opacity }, extra));
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.85, 32, 32), mat(0.4));
  const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(1.25, 2), mat(0.5, { wireframe: true }));
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.75, 0.014, 8, 120), mat(0.8));
  const ring2 = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.01, 8, 120), mat(0.5));
  ring2.rotation.y = Math.PI / 2;
  const N = 200, pos = new Float32Array(N * 3);      // little floating dots around the orb
  for (let i = 0; i < N; i++) {
    const r = 1.9 + Math.random() * 0.5, a = Math.random() * 6.283, b = Math.acos(2 * Math.random() - 1);
    pos.set([r * Math.sin(b) * Math.cos(a), r * Math.sin(b) * Math.sin(a), r * Math.cos(b)], i * 3);
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  const dots = new THREE.Points(geo, new THREE.PointsMaterial({ size: 0.04, transparent: true, opacity: 0.9 }));
  group.add(core, shell, ring, ring2, dots);

  // Colors come from the theme's CSS variables (--hue, --sat)
  api.recolor = function () {
    const cs = getComputedStyle(document.documentElement);
    const hue = parseFloat(cs.getPropertyValue("--hue")) / 360;
    const sat = parseFloat(cs.getPropertyValue("--sat")) / 100;
    const shift = parseFloat(cs.getPropertyValue("--shift")) / 360;
    const light = document.documentElement.dataset.mode === "light" ? 0.45 : 0.6;
    const c1 = new THREE.Color().setHSL(hue, sat, light);
    const c2 = new THREE.Color().setHSL((hue + shift + 1) % 1, sat, light + 0.02);
    core.material.color.copy(c1); shell.material.color.copy(c2);
    ring.material.color.copy(c1); ring2.material.color.copy(c2); dots.material.color.copy(c2);
    draw();
  };

  let t = 0, last = 0, scale = 1, running = false;
  function draw() { renderer.render(scene, camera); }
  function frame(now) {
    if (!running) return;
    requestAnimationFrame(frame);
    const dt = Math.min((now - last) / 1000, 0.05); last = now; t += dt;
    const s = api.state;
    let speed = 0.3, target = 1 + 0.03 * Math.sin(t * 1.6);                 // idle: gentle breathing
    if (s === "thinking") { speed = 1.6; target = 1 + 0.1 * Math.sin(t * 7); }
    if (s === "speaking") { speed = 0.6; target = 1 + 0.07 * Math.sin(t * 9); }
    if (s === "listening") { speed = 0.5 + api.level * 2; target = 1 + 0.05 * Math.sin(t * 3) + api.level * 0.5; }
    scale += (target - scale) * 0.2;                                         // smooth movement
    group.scale.setScalar(scale);
    group.rotation.y += dt * speed;
    group.rotation.x = Math.sin(t * 0.4) * 0.25;
    shell.rotation.z += dt * speed * 0.6;
    ring.rotation.x += dt * speed;
    ring2.rotation.z -= dt * speed * 0.8;
    dots.rotation.y -= dt * speed * 0.4;
    draw();
  }
  function start() { if (!running && api.enabled && api.slot && !document.hidden) { running = true; last = performance.now(); requestAnimationFrame(frame); } }
  function stop() { running = false; }

  api.mount = function (slot) {
    this.slot = slot; slot.innerHTML = ""; slot.appendChild(renderer.domElement);
    const size = Math.max(slot.clientWidth, 64);
    renderer.setSize(size, size, false);
    api.recolor();
    if (this.enabled) start(); else stop();
  };
  api.setEnabled = function (on) { this.enabled = on; if (on) start(); else { stop(); draw(); } };

  document.addEventListener("visibilitychange", () => (document.hidden ? stop() : start()));   // pause in background tab
  window.addEventListener("resize", () => { if (api.slot) api.mount(api.slot); });
  window.addEventListener("themechange", () => api.recolor());
  return api;
})();
