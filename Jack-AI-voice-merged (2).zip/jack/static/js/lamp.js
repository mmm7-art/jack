/* Jack - desk lamp + "Instruction Diary" on the Instruction page.
   Plain JavaScript, no libraries. Sounds use the Web Audio API (no sound files).
   Flow: pull the lamp chain (or click the lamp) -> light falls on the diary -> click the diary -> binder popup
   -> tap one of 5 items -> full instructions -> tap an example to copy it. */
(function () {
  "use strict";
  const scene = document.getElementById("lampScene");
  if (!scene) return;
  const $ = id => document.getElementById(id);
  const lampBtn = $("lampBtn"), swBtn = $("lampSwitch"), diaryBtn = $("diaryBtn"), hint = $("lampHint");
  const modal = $("diaryModal"), closeBtn = $("diaryClose"), right = $("idmRight"), crumb = $("idmCrumb"), toast = $("idmToast");
  let on = false, toastTimer = null, nudgeTimer = null, pullTimer = null;

  /* ---------------- tiny sounds ---------------- */
  let ac = null;
  function audio() {
    try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === "suspended") ac.resume(); } catch (e) { ac = null; }
    return ac;
  }
  function noise(ctx, dur) {
    const buf = ctx.createBuffer(1, Math.max(1, Math.floor(ctx.sampleRate * dur)), ctx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    const src = ctx.createBufferSource(); src.buffer = buf; return src;
  }
  function clickSound() {
    const ctx = audio(); if (!ctx) return;
    const t = ctx.currentTime, g = ctx.createGain(), f = ctx.createBiquadFilter();
    f.type = "bandpass"; f.frequency.value = 2400; g.gain.setValueAtTime(0.2, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
    const n = noise(ctx, 0.07); n.connect(f); f.connect(g); g.connect(ctx.destination); n.start(t);
    const o = ctx.createOscillator(), og = ctx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(180, t); o.frequency.exponentialRampToValueAtTime(70, t + 0.09);
    og.gain.setValueAtTime(0.14, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    o.connect(og); og.connect(ctx.destination); o.start(t); o.stop(t + 0.11);
  }
  function pageSound() {
    const ctx = audio(); if (!ctx) return;
    const t = ctx.currentTime, n = noise(ctx, 0.3), f = ctx.createBiquadFilter(), g = ctx.createGain();
    f.type = "bandpass"; f.frequency.setValueAtTime(900, t); f.frequency.linearRampToValueAtTime(3200, t + 0.25); f.Q.value = 0.8;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.08, t + 0.07); g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    n.connect(f); f.connect(g); g.connect(ctx.destination); n.start(t);
  }

  /* ---------------- the lamp ---------------- */
  function setHint(text) {
    if (hint.textContent === text) return;
    hint.textContent = text; hint.classList.remove("swap"); void hint.offsetWidth; hint.classList.add("swap");
  }
  function setLamp(state) {
    on = state;
    scene.classList.toggle("on", on);
    scene.dataset.lamp = on ? "on" : "off";
    lampBtn.setAttribute("aria-pressed", String(on));
    swBtn.setAttribute("aria-checked", String(on));
    diaryBtn.setAttribute("aria-disabled", String(!on));
    setHint(on ? "Ab diary par click karo \uD83D\uDCD6" : "Lamp ON karo \uD83D\uDCA1");
    if (on) { scene.classList.add("flick"); setTimeout(() => scene.classList.remove("flick"), 520); }
  }
  function pullChain() {
    swBtn.classList.remove("pull"); void swBtn.getBoundingClientRect(); swBtn.classList.add("pull");
    clearTimeout(pullTimer); pullTimer = setTimeout(() => swBtn.classList.remove("pull"), 700);
  }
  function toggleLamp() { clickSound(); pullChain(); setLamp(!on); }
  function activate(el, fn) {
    el.addEventListener("click", fn);
    el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fn(); } });
  }
  activate(lampBtn, toggleLamp);
  activate(swBtn, e => { toggleLamp(); });
  swBtn.addEventListener("click", e => e.stopPropagation());

  /* ---------------- the instructions (Pakistani Roman Urdu, SMS style) ---------------- */
  const SECTIONS = [
    { id: "start", n: 1, title: "Getting Started", sub: "Jack ko shuru karna aur basics",
      intro: "Salam! Jack tumhara apna AI assistant hai. Likh kar ya bol kar kaam bata do, Jack kar dega. Yahan se shuru karo.",
      blocks: [
        { h: "\uD83D\uDE80 Jack ko chalana", steps: ["Project folder mein Command Prompt kholo aur neeche wala command likho.", "Chrome ya Edge mein localhost:5000 kholo.", "Upar Chat par click karo aur apna pehla command likho."],
          ex: ["python app.py", "help"] },
        { h: "\u23F0 Waqt aur tarikh", steps: ["time likho to abhi ka waqt batayega, date likho to aaj ki tarikh."],
          ex: ["time", "date", "system info"] },
        { h: "\uD83C\uDF10 Website kholna", steps: ["open likho aur site ka naam likho, Jack naye tab mein khol dega."],
          ex: ["open youtube", "open gmail", "open github"] }
      ] },
    { id: "voice", n: 2, title: "Voice Assistant", sub: "Bol kar kaam karwao, gaane sunao",
      intro: "Type karna nahi chahte? Mic dabao aur bolo. Jack English, Urdu aur Sindhi samajhta hai aur usi zuban mein jawab deta hai.",
      blocks: [
        { h: "\uD83C\uDFA4 Voice se baat karna", steps: ["Upar Voice page kholo.", "Zuban chuno: English, Urdu ya Sindhi.", "Tap to speak dabao aur bolo. Mic na chale to neeche box mein type kar do, wo bhi chalega."],
          lbl: "Voice mein ye bol kar dekho", ex: ["gaana chalao tum hi ho", "naukri dikhao", "\u06AF\u0627\u0646\u0627 \u0686\u0644\u0627\u0624 \u062A\u0645 \u06C1\u06CC \u06C1\u0648"] },
        { h: "\uD83C\uDFB5 Music (gaane)", steps: ["play likho aur song ka naam likho, Jack wo gana chala dega.", "Jack YouTube par pehli video dhoond kar foran chala deta hai."],
          ex: ["play believer", "play tum hi ho", "kesariya bajao"] }
      ] },
    { id: "tools", n: 3, title: "Tools & Features", sub: "Slides, Word, Excel, charts aur bohat kuch",
      intro: "Ye sab Chat mein likh kar chalte hain. Banai hui files Desktop ke Jack Output folder mein milti hain. Example par tap karo, copy ho jayega, phir Chat mein paste kar do.",
      blocks: [
        { h: "\uD83D\uDCCA Slides (PowerPoint)", steps: ["ppt on likho aur topic ka naam, Jack slides bana kar Desktop par rakh dega."],
          ex: ["ppt on artificial intelligence", "ppt on climate change", "presentation on cyber security"] },
        { h: "\uD83D\uDCDD Word document", steps: ["word on likho aur topic ka naam, Jack poori Word file bana dega."],
          ex: ["word on time management", "word on global warming", "make word document about my final year project"] },
        { h: "\uD83D\uDCD7 Excel", steps: ["excel likho aur topic ya apna data likho. Data mein column comma se aur row semicolon se alag karo.", "record likho to saare notes aur tasks Excel mein save ho jate hain."],
          ex: ["excel Name,Age; Ali,20; Sara,22", "excel monthly budget", "record Item,Price; Atta,1500; Doodh,220"] },
        { h: "\uD83D\uDCC8 Charts", steps: ["chart likho, phir naam aur values likho. Bar chart default hai, pie ya line bhi bana sakte ho."],
          ex: ["chart sales: jan=10, feb=20, mar=15", "pie chart marks: urdu=70, math=85, english=78", "line chart temp: mon=30, tue=33, wed=31"] },
        { h: "\uD83D\uDCCB Table aur Diagram", steps: ["table se Word table banti hai, diagram se step-by-step flow ki picture."],
          ex: ["table Name,Age; Ali,20; Sara,22", "diagram plan: idea -> design -> build -> test -> launch"] },
        { h: "\uD83D\uDCBC Job research", steps: ["jobs ya naukri dikhao likho, Jack Google Jobs se software jobs dhoond kar Word report bana dega.", "Iske liye .env file mein SERPAPI_KEY lagana zaroori hai."],
          ex: ["jobs", "naukri dikhao", "job dikhao software engineering pakistan"] },
        { h: "\u26C5 Mausam (weather)", steps: ["weather in likho aur shehar ka naam, Jack temperature, humidity aur hawa batayega."],
          ex: ["weather in Lahore", "weather in Karachi", "weather in Islamabad"] },
        { h: "\uD83D\uDCDA Wikipedia", steps: ["wiki likho aur kisi cheez ya shakhs ka naam, Jack chhota sa summary la dega."],
          ex: ["wiki Alan Turing", "wiki Allama Iqbal", "what is Python"] },
        { h: "\uD83E\uDDEE Calculator", steps: ["calc likho aur hisaab likho. Brackets aur sqrt bhi chalte hain."],
          ex: ["calc 12*(3+4)", "calc 2500*12", "calc sqrt(144)+10"] },
        { h: "\uD83D\uDE04 Jokes aur mazay", steps: ["Mood kharab ho to joke likho. quote se achi baat milti hai.", "Faisla na ho raha ho to flip coin likho."],
          ex: ["joke", "quote", "flip coin"] },
        { h: "\uD83D\uDDD2\uFE0F Notes aur tasks", steps: ["note likho aur baat likho, Jack yaad rakhega. notes likho to saare notes dikhenge.", "todo se kaam ki list banti hai. done 1 likho to pehla kaam complete ho jata hai."],
          ex: ["note kal 5 baje assignment submit karni hai", "notes", "todo project ka report likhna"] }
      ] },
    { id: "settings", n: 4, title: "Settings", sub: "Themes, dark/light mode aur options",
      intro: "Website ko apne mizaj ka bana lo. Sab kuch yaad rehta hai, dobara kholne par wahi theme milegi.",
      blocks: [
        { h: "\uD83C\uDFA8 Themes (5 rang)", steps: ["Upar Theme button dabao.", "5 mein se ek chuno: Midnight AI, Purple Galaxy, Apple Frost, Emerald Matrix ya Amber Luxe."],
          ex: ["Theme > Purple Galaxy", "Theme > Emerald Matrix", "Theme > Amber Luxe"] },
        { h: "\uD83C\uDF13 Dark / Light mode", steps: ["Upar chaand ya suraj wala gol button dabao.", "Ya Settings page mein Mode wala button dabao."],
          ex: ["Settings > Mode: dark", "Settings > Mode: light"] },
        { h: "\uD83D\uDD0A Voice replies aur effects", steps: ["Jack ki awaaz band karni ho to Settings mein Voice replies off kar do.", "Phone ya purana laptop slow chale to Light effects on kar do."],
          ex: ["Settings > Voice replies: off", "Settings > Light effects: on"] }
      ] },
    { id: "help", n: 5, title: "Help & Support", sub: "Masla aaye to yahan dekho",
      intro: "Koi cheez na chale to ghabrao mat. Zyada tar masle in mein se hi hote hain.",
      blocks: [
        { h: "\uD83D\uDD34 \"Server is not running\" likha aaye", steps: ["Command Prompt mein project folder ke andar ye command chalao aur page refresh kar do."],
          ex: ["python app.py"] },
        { h: "\uD83E\uDDE0 AI jawab nahi de raha", steps: [".env file kholo aur ANTHROPIC_API_KEY ke baad apni key paste karo.", "Phir Jack band kar ke dobara chalao (Ctrl+C, phir python app.py)."],
          ex: ["ANTHROPIC_API_KEY=sk-ant-xxxxxxxx"] },
        { h: "\uD83D\uDCBC Jobs nahi aa rahi", steps: [".env file mein SERPAPI_KEY lagao. Serpapi.com par free plan se bhi kaam chal jata hai."],
          ex: ["SERPAPI_KEY=xxxxxxxxxxxxxxxx"] },
        { h: "\uD83C\uDFA4 Mic nahi chal raha", steps: ["Chrome ya Edge use karo, aur mic ki permission Allow karo.", "Sindhi mein dikkat ho to Urdu chuno ya neeche box mein type kar do."],
          ex: [] },
        { h: "\u2753 Commands bhool gaye?", steps: ["Chat mein help likho, Jack saare commands ki list dikha dega."],
          ex: ["help"] }
      ] }
  ];

  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  function renderList() {
    crumb.textContent = "";
    right.innerHTML =
      '<p class="idm-head">Kya jaanna hai? Ek chuno \uD83D\uDC47</p><ol class="idm-list">' +
      SECTIONS.map(s => '<li><button type="button" class="idm-item" data-id="' + s.id + '"><span class="badge b' + s.n + '">' + s.n + '</span>' +
        '<span><b>' + esc(s.title) + '</b><small>' + esc(s.sub) + '</small></span><span class="chev" aria-hidden="true">\u203A</span></button></li>').join("") +
      '</ol><p class="idm-foot">Explore \u00B7 Learn \u00B7 Grow \u2665</p>';
    right.scrollTop = 0;
  }
  function renderDetail(id) {
    const s = SECTIONS.find(x => x.id === id); if (!s) return renderList();
    crumb.textContent = s.n + ". " + s.title;
    right.innerHTML = '<div class="detail"><div class="d-top"><button type="button" class="d-back" data-back>\u2039 Wapas</button><h3>' + s.n + ". " + esc(s.title) + '</h3></div>' +
      '<p class="d-intro">' + esc(s.intro) + '</p>' +
      s.blocks.map(b => '<section class="blk"><h4>' + esc(b.h) + '</h4>' +
        (b.steps.length > 1 ? '<ol>' + b.steps.map(t => '<li>' + esc(t) + '</li>').join("") + '</ol>' : '<p>' + esc(b.steps[0]) + '</p>') +
        (b.ex.length ? '<p class="ex-lbl">' + esc(b.lbl || "Example (tap karo, copy ho jayega)") + '</p>' +
          b.ex.map(t => '<button type="button" class="ex" data-copy="' + esc(t) + '" dir="auto"><span>' + esc(t) + '</span><span class="cp">COPY</span></button>').join("") : "") +
        '</section>').join("") + '</div>';
    right.scrollTop = 0;
    const back = right.querySelector("[data-back]"); if (back) back.focus({ preventScroll: true });
  }

  /* ---------------- copy an example ---------------- */
  function showToast(msg) {
    toast.textContent = msg; toast.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 1600);
  }
  function fallbackCopy(text) {
    const ta = document.createElement("textarea");
    ta.value = text; ta.setAttribute("readonly", ""); ta.style.cssText = "position:fixed;left:-9999px;top:0";
    document.body.append(ta); ta.select();
    let ok = false; try { ok = document.execCommand("copy"); } catch (e) {}
    ta.remove(); return ok;
  }
  async function copyText(text) {
    try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); return true; } } catch (e) {}
    return fallbackCopy(text);
  }
  right.addEventListener("click", async e => {
    const item = e.target.closest(".idm-item"), back = e.target.closest("[data-back]"), ex = e.target.closest(".ex");
    if (item) { pageSound(); renderDetail(item.dataset.id); }
    else if (back) { pageSound(); renderList(); const first = right.querySelector(".idm-item"); if (first) first.focus({ preventScroll: true }); }
    else if (ex) {
      const ok = await copyText(ex.dataset.copy);
      ex.classList.toggle("done", ok); ex.querySelector(".cp").textContent = ok ? "COPIED \u2713" : "COPY";
      showToast(ok ? "Copy ho gaya \u2713 Ab Chat mein paste karo" : "Copy nahi hua, text select kar ke copy karo");
      setTimeout(() => { ex.classList.remove("done"); ex.querySelector(".cp").textContent = "COPY"; }, 1800);
    }
  });

  /* ---------------- the diary popup ---------------- */
  function openDiary() {
    if (!on) {                                           // the diary is dark and locked until the lamp is ON
      setHint("Pehle lamp ON karo \uD83D\uDCA1");
      scene.classList.remove("nudge"); void scene.offsetWidth; scene.classList.add("nudge");
      clearTimeout(nudgeTimer); nudgeTimer = setTimeout(() => scene.classList.remove("nudge"), 500);
      return;
    }
    renderList();
    modal.hidden = false; document.documentElement.classList.add("lock");
    pageSound();
    closeBtn.focus({ preventScroll: true });
  }
  function closeDiary() {
    if (modal.hidden) return;
    modal.hidden = true; document.documentElement.classList.remove("lock"); toast.classList.remove("show");
    try { diaryBtn.focus({ preventScroll: true }); } catch (e) {}
  }
  activate(diaryBtn, openDiary);
  closeBtn.addEventListener("click", closeDiary);
  modal.addEventListener("click", e => { if (e.target === modal) closeDiary(); });
  document.addEventListener("keydown", e => {
    if (modal.hidden) return;
    if (e.key === "Escape") { e.preventDefault(); closeDiary(); return; }
    if (e.key === "Tab") {                               // keep keyboard focus inside the popup
      const f = Array.from(modal.querySelectorAll("button:not([disabled])")).filter(b => b.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  window.addEventListener("hashchange", closeDiary);     // leaving the Home page closes the popup

  setLamp(false);
})();
