/* Jack - Theme Ripple + Glow Sweep. Plain JS. Call JackTheme.change(name, clickEvent, buttonEl).
   Timeline: 0-150ms button glow | 150-700ms ripple wave | 700-1000ms final glow | stable.
   Uses View Transitions (clip-path circle) when available, otherwise an expanding overlay. */
window.JackTheme = (function () {
  const root = document.documentElement, EASE = "cubic-bezier(0.22, 1, 0.36, 1)";
  /* accent = ripple/glow color of the NEW theme, tint = overlay color for the fallback */
  const LOOK = {
    navygold: { accent: "#D4AF37", tint: "#0B132B" },
    rainbow:  { accent: "#ff8ad0", tint: "#f3e3ff", grad: "linear-gradient(135deg,#ff9ad5,#b79cff,#7fd0ff)" },
    copper:   { accent: "#e0a878", tint: "#1c110b" },
    lavender: { accent: "#9a6bff", tint: "#e4d8ff" },
    neon:     { accent: "#2f9bff", tint: "#060a26" }
  };
  let busy = false;
  const reduced = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const el = (cls, css) => { const d = document.createElement("div"); d.className = cls; Object.assign(d.style, css); document.body.append(d); return d; };

  async function change(name, ev, btn) {
    if (busy || !LOOK[name] || name === root.dataset.theme) return;
    busy = true;
    const look = LOOK[name], apply = () => window.setTheme(name);
    try {
      if (reduced() || root.dataset.fx === "low") {            // reduced motion: quick fade, no ripple
        if (document.startViewTransition) await document.startViewTransition(apply).finished; else apply();
        return;
      }
      const r = btn ? btn.getBoundingClientRect() : null;
      const x = ev && ev.clientX ? ev.clientX : r ? r.left + r.width / 2 : innerWidth / 2;
      const y = ev && ev.clientY ? ev.clientY : r ? r.top + r.height / 2 : innerHeight / 2;
      const R = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
      if (btn) {                                               // 1) glow circle inside the clicked swatch
        const g = document.createElement("i"); g.className = "tr-glow";
        g.style.cssText = `--x:${x - r.left}px;--y:${y - r.top}px;--c:${look.accent}`; btn.append(g);
        setTimeout(() => g.remove(), 700);
      }
      await wait(150);
      const ring = `radial-gradient(circle,transparent 60%,${look.accent} 64%,transparent 72%)`;
      let wave = el("tr-wave", { left: x - R + "px", top: y - R + "px", width: 2 * R + "px", height: 2 * R + "px", background: look.grad ? look.grad : ring });
      wave.style.background = ring;                            // soft colored edge that travels with the wave
      if (document.startViewTransition) {                      // 2-3) real UI changes inside the growing circle
        root.dataset.vt = "ripple";
        const vt = document.startViewTransition(apply);
        await vt.ready;
        root.animate({ clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${R}px at ${x}px ${y}px)`] },
          { duration: 550, easing: EASE, pseudoElement: "::view-transition-new(root)" });
        wave.animate([{ transform: "scale(0)", opacity: 1 }, { transform: "scale(1)", opacity: 0 }], { duration: 550, easing: EASE, fill: "forwards" });
        await wait(550); await vt.finished.catch(() => {});
      } else {                                                 // fallback: tinted overlay expands, theme switches mid-way
        wave.style.background = `radial-gradient(circle,${look.tint} 0,${look.tint} 58%,${look.accent} 64%,transparent 70%)`;
        wave.animate([{ transform: "scale(0)" }, { transform: "scale(1)" }], { duration: 550, easing: EASE, fill: "forwards" });
        await wait(380); apply(); await wait(170);
        wave.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 200, fill: "forwards" });
      }
      wave.remove();
      const fin = el("tr-final", { background: `radial-gradient(circle at ${x}px ${y}px,${look.accent}33,transparent 70%)`, boxShadow: `inset 0 0 120px ${look.accent}40` });
      await fin.animate([{ opacity: 0 }, { opacity: 1, offset: .45 }, { opacity: 0 }], { duration: 300, easing: "ease-in-out" }).finished;
      fin.remove();                                            // 5) final glow done -> stable
    } finally {
      delete root.dataset.vt; busy = false;
      if (root.dataset.theme !== name) apply();                // safety: never leave the old theme
    }
  }
  return { change, isBusy: () => busy };
})();
