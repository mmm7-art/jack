/* Jack - frontend logic: themes, pages, chat, voice, notes/tasks, zip, 3D tilt. Plain JavaScript. */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const root = document.documentElement;
const SERVER_DOWN = "Server is not running. Run python app.py";
const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
const load = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };

/* ---------------- Themes (saved in localStorage) ---------------- */
const DEFAULT_MODE = { navygold: "dark", rainbow: "light", copper: "dark", lavender: "light", neon: "dark" };   // each theme has its own look
function setTheme(name, mode) {
  if (!DEFAULT_MODE[name]) name = "navygold";
  root.dataset.theme = name;
  root.dataset.mode = mode || DEFAULT_MODE[name] || "dark";
  save("jack-theme", root.dataset.theme); save("jack-mode", root.dataset.mode);
  $$("[data-theme].theme-pick").forEach(b => b.classList.toggle("on", b.dataset.theme === name));
  $("#modeBtn2").textContent = "Mode: " + root.dataset.mode;
  window.dispatchEvent(new Event("themechange"));      // the orb listens to this and changes color
}
function toggleMode() { setTheme(root.dataset.theme, root.dataset.mode === "dark" ? "light" : "dark"); }

const themeBtn = $("#themeBtn"), themeMenu = $("#themeMenu");
themeBtn.onclick = e => { e.stopPropagation(); themeMenu.hidden = !themeMenu.hidden; themeBtn.setAttribute("aria-expanded", !themeMenu.hidden); };
document.addEventListener("click", () => { themeMenu.hidden = true; });
/* every theme button (navbar menu + Settings swatches) uses the same ripple switcher */
$$("button[data-theme]").forEach(b => b.addEventListener("click", e => {
  e.stopPropagation(); JackTheme.change(b.dataset.theme, e, b);
  setTimeout(() => { themeMenu.hidden = true; themeBtn.setAttribute("aria-expanded", "false"); }, 170);
}));
$("#modeBtn").onclick = toggleMode; $("#modeBtn2").onclick = toggleMode;

/* ---------------- Light effects switch ---------------- */
function setFx(low) {
  root.dataset.fx = low ? "low" : "full"; save("jack-fx", root.dataset.fx);
  $("#fxToggle").setAttribute("aria-pressed", low); $("#fxToggle").textContent = "Light effects: " + (low ? "on" : "off");
  JackOrb.setEnabled(!low);
}
$("#fxToggle").onclick = () => setFx(root.dataset.fx !== "low");

/* ---------------- Pages (Home, Chat, Voice, Tools, Settings) ---------------- */
function showView(name) {
  if (!$("#view-" + name)) name = "home";
  $$(".view").forEach(v => v.hidden = v.id !== "view-" + name);
  $$("#mainNav a, #instBtn").forEach(a => a.classList.toggle("on", a.dataset.view === name));
  document.documentElement.classList.toggle("inst-mode", name === "instruction");
  const slot = $(`#view-${name} .orb-slot`);
  if (slot) JackOrb.mount(slot);                       // one orb, moved into the visible page
  if (name === "chat") { scrollLog(); $("#input").focus({ preventScroll: true }); }
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", () => showView(location.hash.slice(1)));
function go(name) { if (location.hash.slice(1) === name) showView(name); else location.hash = name; }

/* ---------------- Chat ---------------- */
const log = $("#log"), input = $("#input");
const scrollLog = () => { log.scrollTop = log.scrollHeight; };
let speakOn = load("jack-speak", "on") === "on";
function paintSpeak() { const b = $("#speakToggle"); b.setAttribute("aria-pressed", speakOn); b.textContent = "Voice replies: " + (speakOn ? "on" : "off"); }
$("#speakToggle").onclick = () => { speakOn = !speakOn; save("jack-speak", speakOn ? "on" : "off"); paintSpeak(); if (!speakOn) speechSynthesis.cancel(); };

function addMsg(text, who, extra = {}) {
  const d = document.createElement("div");
  d.className = "msg " + who;
  d.dir = "auto";                                      // Urdu / Sindhi text flows right-to-left, English left-to-right
  d.textContent = text;
  if (extra.file) d.append(makeLink("Download " + extra.file.name, extra.file.url, true));
  if (extra.link) d.append(makeLink(extra.link.label, extra.link.url));
  if (extra.action) d.append(makeLink("Open link", extra.action.url));
  log.append(d); scrollLog();
  return d;
}
function makeLink(label, url, download) {
  const a = document.createElement("a");
  a.className = "btn"; a.textContent = label; a.href = url;
  if (download) a.setAttribute("download", ""); else { a.target = "_blank"; a.rel = "noopener"; }
  return a;
}
let typingEl = null;
function showTyping(on) {                               // the three bouncing dots
  if (on && !typingEl) {
    typingEl = document.createElement("div"); typingEl.className = "msg jack typing";
    typingEl.innerHTML = "<i></i><i></i><i></i>"; log.append(typingEl); scrollLog();
  } else if (!on && typingEl) { typingEl.remove(); typingEl = null; }
}
function setBusy(on) {
  JackOrb.setState(on ? "thinking" : "idle");
  $("#status").textContent = on ? "Thinking..." : "Ready";
}

function speak(text) {
  if (!speakOn || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text.replace(/\s+/g, " ").slice(0, 1800));
  const selected = getVoiceLang();
  u.lang = selected === "auto" ? (/[\u0600-\u06FF]/.test(text) ? "ur-PK" : "en-US") : selected;
  const voices = speechSynthesis.getVoices();
  const voice = voices.find(v => (v.lang || "").toLowerCase() === u.lang.toLowerCase())
    || voices.find(v => (v.lang || "").toLowerCase().startsWith(u.lang.split("-")[0].toLowerCase()));
  if (voice) u.voice = voice;
  u.rate = 1.02; u.pitch = 1.0;
  u.onstart = () => JackOrb.setState("speaking");
  u.onend = u.onerror = () => {
    JackOrb.setState("idle");
    if (voiceSession && !voiceMuted) setTimeout(startContinuousRecognition, 250);
  };
  speechSynthesis.speak(u);
}

async function send(text) {
  text = text.trim();
  if (!text) return;
  addMsg(text, "me");
  $("#voiceHeard").textContent = text;
  showTyping(true); setBusy(true);
  let reply;
  try {
    const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text }) });
    const data = await r.json();
    reply = data.reply || data.error || "No reply.";
    showTyping(false);
    addMsg(reply, "jack", data);
    if (data.action && data.action.type === "open") window.open(data.action.url, "_blank", "noopener");
    speak(reply);
    refreshLists();
    $("#offline").hidden = true;
  } catch (e) {                                         // fetch fails when Flask is not running
    showTyping(false);
    reply = SERVER_DOWN;
    addMsg(reply, "jack error");
    $("#offline").hidden = false;
  }
  setBusy(false);
  $("#voiceReply").textContent = reply;
  return reply;
}
$("#form").addEventListener("submit", e => { e.preventDefault(); const v = input.value; input.value = ""; send(v); });

/* Buttons that run or fill a command: data-cmd runs it, data-fill types it in the chat box */
document.addEventListener("click", e => {
  const el = e.target.closest("[data-cmd],[data-fill],[data-go]");
  if (!el) return;
  if (el.dataset.go) return go(el.dataset.go);
  go("chat");
  if (el.dataset.cmd) send(el.dataset.cmd);
  else { input.value = el.dataset.fill; input.focus(); }
});

/* ---------------- Enhanced voice session (merged from the second voice app) ---------------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null, meter = null, voiceSession = false, voiceMuted = false, captionsEnabled = true;
let restartingVoice = false;

async function startMeter() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const an = ctx.createAnalyser(); an.fftSize = 256;
    ctx.createMediaStreamSource(stream).connect(an);
    const buf = new Uint8Array(an.frequencyBinCount);
    meter = { stream, ctx, on: true };
    (function tick() {
      if (!meter || !meter.on) return;
      an.getByteFrequencyData(buf);
      JackOrb.setLevel(Math.min(buf.reduce((a, b) => a + b, 0) / buf.length / 90, 1));
      requestAnimationFrame(tick);
    })();
  } catch (e) { meter = null; }
}
function stopMeter() {
  if (meter) { meter.on = false; meter.stream.getTracks().forEach(t => t.stop()); meter.ctx.close(); meter = null; }
  JackOrb.setLevel(0);
}
const VOICE_LANGS = ["auto", "en-US", "ur-PK", "sd-PK"];
const voiceLangSel = $("#voiceLang");
const getVoiceLang = () => {
  const v = load("jack-voice-lang", "ur-PK");
  return VOICE_LANGS.includes(v) ? v : "ur-PK";
};
voiceLangSel.value = getVoiceLang();
voiceLangSel.addEventListener("change", () => { save("jack-voice-lang", voiceLangSel.value); voiceNote(""); });

function voiceNote(text) {
  const el = $("#voiceMsg");
  el.textContent = text || "";
  el.hidden = !text;
}
const VMSG = {
  unsupported: "Voice input is not supported here. Open Jack in Chrome or Edge, or type your message.",
  denied: "Microphone permission is blocked. Allow microphone access in your browser settings.",
  nomic: "No microphone was found. Connect a microphone or type your message.",
  network: "Speech recognition needs an internet connection.",
  nothing: "I could not hear anything. Please try again.",
};
if (!SR) voiceNote(VMSG.unsupported);

function resolvedRecognitionLanguage(text) {
  const selected = getVoiceLang();
  if (selected !== "auto") return selected;
  if (/[ڳښ]/.test(text || "")) return "sd-PK";
  if (/[؀-ۿ]/.test(text || "")) return "ur-PK";
  return "en-US";
}
function updateVoiceStatus(text) { $("#voiceStatus").textContent = text; }
function stopRecognition() {
  if (rec) {
    const old = rec; rec = null;
    try { old.onend = null; old.stop(); } catch (e) {}
  }
  stopMeter();
  $("#voiceMic").classList.remove("listening");
}
function startContinuousRecognition() {
  if (!SR || !voiceSession || voiceMuted || rec || speechSynthesis.speaking) return;
  let heard = "", finalText = "";
  const r = new SR();
  rec = r;
  r.lang = getVoiceLang() === "auto" ? "en-US" : getVoiceLang();
  r.continuous = true;
  r.interimResults = true;
  r.maxAlternatives = 1;
  r.onstart = () => {
    updateVoiceStatus("Listening…");
    JackOrb.setState("listening");
    $("#voiceMic").classList.add("listening");
    startMeter();
  };
  r.onresult = e => {
    let interim = "";
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const result = e.results[i];
      const transcript = (result[0].transcript || "").trim();
      if (!transcript) continue;
      interim += transcript + " ";
      if (result.isFinal) finalText = transcript;
    }
    heard = interim.trim() || heard;
    if (captionsEnabled && heard) $("#voiceHeard").textContent = heard;
    if (finalText) {
      const message = finalText.trim();
      finalText = "";
      stopRecognition();
      send(message).finally(() => {
        if (voiceSession && !voiceMuted) setTimeout(startContinuousRecognition, 250);
      });
    }
  };
  r.onerror = e => {
    if (e.error === "not-allowed" || e.error === "permission-denied" || e.error === "service-not-allowed") {
      voiceNote(VMSG.denied); voiceSession = false; updateVoiceStatus("Microphone permission needed.");
    } else if (e.error === "audio-capture") {
      voiceNote(VMSG.nomic); voiceSession = false;
    } else if (e.error === "network") {
      voiceNote(VMSG.network);
    } else if (e.error !== "no-speech" && e.error !== "aborted") {
      voiceNote("Voice recognition had a problem. Please try again.");
    }
  };
  r.onend = () => {
    if (rec === r) rec = null;
    stopMeter();
    $("#voiceMic").classList.remove("listening");
    if (voiceSession && !voiceMuted && !speechSynthesis.speaking) {
      JackOrb.setState("idle");
      setTimeout(startContinuousRecognition, 250);
    }
  };
  try { r.start(); } catch (e) { if (rec === r) rec = null; updateVoiceStatus("Tap Start voice and allow microphone access."); }
}
function listen() {
  if (!SR) { voiceNote(VMSG.unsupported); return; }
  if (rec) { stopRecognition(); updateVoiceStatus("Voice paused."); return; }
  voiceSession = true;
  voiceMuted = false;
  $("#voiceMute").textContent = "Mic on";
  $("#voiceMute").setAttribute("aria-pressed", "false");
  startContinuousRecognition();
}
$("#voiceMic").onclick = listen;
$("#voiceSessionStart").onclick = () => {
  if (!SR) { voiceNote(VMSG.unsupported); return; }
  voiceSession = true; voiceMuted = false; voiceNote("");
  $("#voiceMute").textContent = "Mic on";
  $("#voiceMute").setAttribute("aria-pressed", "false");
  updateVoiceStatus("Starting voice session…");
  startContinuousRecognition();
};
$("#voiceSessionEnd").onclick = () => {
  voiceSession = false; voiceMuted = false;
  stopRecognition();
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  JackOrb.setState("idle");
  updateVoiceStatus("Voice session ended.");
};
$("#voiceMute").onclick = () => {
  voiceMuted = !voiceMuted;
  $("#voiceMute").textContent = voiceMuted ? "Mic muted" : "Mic on";
  $("#voiceMute").setAttribute("aria-pressed", String(voiceMuted));
  if (voiceMuted) {
    stopRecognition();
    if ("speechSynthesis" in window) speechSynthesis.cancel();
    updateVoiceStatus("Microphone muted.");
  } else {
    updateVoiceStatus("Listening…");
    startContinuousRecognition();
  }
};
$("#voiceCaptions").onclick = () => {
  captionsEnabled = !captionsEnabled;
  $("#voiceCaptions").textContent = captionsEnabled ? "Captions on" : "Captions off";
  $("#voiceCaptions").setAttribute("aria-pressed", String(captionsEnabled));
  $("#voiceCaptionBox").hidden = !captionsEnabled;
};
$("#voiceForm").addEventListener("submit", e => {
  e.preventDefault();
  const box = $("#voiceText"), v = box.value.trim();
  if (!v) return;
  box.value = ""; voiceNote(""); send(v);
});

/* ---------------- Notes and tasks panels ---------------- */
async function loadList(kind) {
  const ul = $(`#panel-${kind} .list`);
  try {
    const items = await (await fetch("/api/" + kind)).json();
    ul.innerHTML = "";
    items.forEach(it => {
      const li = document.createElement("li");
      const span = document.createElement("span");
      span.textContent = (kind === "todos" ? (it.done ? "[x] " : "[ ] ") : "") + it.text;
      const del = document.createElement("button");
      del.textContent = "\u00d7"; del.setAttribute("aria-label", "Delete");
      del.onclick = async () => { await fetch(`/api/${kind}/${it.id}`, { method: "DELETE" }); loadList(kind); };
      li.append(span, del); ul.append(li);
    });
  } catch (e) {}
}
const refreshLists = () => { loadList("notes"); loadList("todos"); };
$$("form.mini").forEach(f => f.addEventListener("submit", async e => {
  e.preventDefault();
  const i = $("input", f);
  await fetch("/api/" + f.dataset.kind, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: i.value }) });
  i.value = ""; loadList(f.dataset.kind);
}));
$$(".tabs button").forEach(b => b.onclick = () => {
  $$(".tabs button").forEach(x => x.classList.toggle("on", x === b));
  $$(".tabpanel").forEach(p => p.hidden = p.id !== "panel-" + b.dataset.tab);
});

/* ---------------- Zip and unzip ---------------- */
$("#zipForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const r = await fetch("/api/zip", { method: "POST", body: new FormData(e.target) });
    if (!r.ok) throw new Error();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(await r.blob()); a.download = "jack-archive.zip"; a.click();
  } catch (err) { addMsg("Could not create the zip. " + SERVER_DOWN, "jack error"); }
});
$("#unzipForm").addEventListener("submit", async e => {
  e.preventDefault();
  const out = $("#unzipOut"); out.innerHTML = "";
  try {
    const d = await (await fetch("/api/unzip", { method: "POST", body: new FormData(e.target) })).json();
    (d.files || []).forEach(f => {
      const li = document.createElement("li"), a = document.createElement("a");
      a.href = f.url; a.textContent = f.name; li.append(a); out.append(li);
    });
    if (d.error) out.innerHTML = "<li>" + d.error + "</li>";
  } catch (err) { out.innerHTML = "<li>" + SERVER_DOWN + "</li>"; }
});

/* ---------------- 3D tilt on cards (light: only moves while the mouse is over a card) ---------------- */
document.addEventListener("mousemove", e => {
  if (root.dataset.fx === "low") return;
  const card = e.target.closest(".tilt");
  if (!card) return;
  const r = card.getBoundingClientRect();
  card.style.setProperty("--ry", ((e.clientX - r.left) / r.width - 0.5) * 10 + "deg");
  card.style.setProperty("--rx", (0.5 - (e.clientY - r.top) / r.height) * 10 + "deg");
});
document.addEventListener("mouseout", e => {
  const card = e.target.closest(".tilt");
  if (card && !card.contains(e.relatedTarget)) { card.style.setProperty("--rx", "0deg"); card.style.setProperty("--ry", "0deg"); }
});

/* ---------------- Start ---------------- */
paintSpeak();
setTheme(root.dataset.theme, root.dataset.mode);
setFx(root.dataset.fx === "low");
showView(location.hash.slice(1) || "home");
addMsg("Yes sir, I'm listening. Type 'help' to see everything I can do.", "jack");
refreshLists();
fetch("/api/health").catch(() => { $("#offline").hidden = false; });     // is the server running?
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
